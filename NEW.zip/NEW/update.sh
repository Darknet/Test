#!/bin/bash

# Dotfiles Update Script
# Updates existing configurations with new features

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

print_color() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

print_header() {
    echo
    print_color $PURPLE "================================"
    print_color $PURPLE "$1"
    print_color $PURPLE "================================"
    echo
}

# Check for updates
check_for_updates() {
    print_header "Checking for Updates"
    
    if [[ -d .git ]]; then
        print_color $BLUE "📡 Fetching latest changes..."
        git fetch origin
        
        local behind=$(git rev-list --count HEAD..origin/main 2>/dev/null || echo "0")
        
        if [[ $behind -gt 0 ]]; then
            print_color $YELLOW "📦 $behind updates available"
            return 0
        else
            print_color $GREEN "✅ Already up to date"
            return 1
        fi
    else
        print_color $YELLOW "⚠️  Not a git repository, skipping update check"
        return 1
    fi
}

# Backup current configuration
backup_current_config() {
    print_header "Creating Backup"
    
    local backup_dir="$HOME/.config/dotfiles-backup-update-$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    
    local configs=(
        "hypr"
        "waybar" 
        "mako"
        "alacritty"
        "rofi"
        "scripts"
    )
    
    for config in "${configs[@]}"; do
        if [[ -d "$HOME/.config/$config" ]]; then
            print_color $BLUE "💾 Backing up $config..."
            cp -r "$HOME/.config/$config" "$backup_dir/"
        fi
    done
    
    print_color $GREEN "✅ Backup created at: $backup_dir"
    echo "$backup_dir" > /tmp/dotfiles_backup_path
}

# Update configurations
update_configs() {
    print_header "Updating Configurations"
    
    # Pull latest changes
    if [[ -d .git ]]; then
        print_color $BLUE "📥 Pulling latest changes..."
        git pull origin main
    fi
    
    # Run installation script to update configs
    if [[ -f install.sh ]]; then
        print_color $BLUE "🔄 Running update installation..."
        bash install.sh
    fi
}

# Main update function
main() {
    print_header "Dotfiles Update Manager"
    
    if check_for_updates; then
        read -p "Do you want to update? (y/N): " -n 1 -r
        echo
        
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            backup_current_config
            update_configs
            
            print_header "Update Complete!"
            print_color $GREEN "✅ Dotfiles updated successfully!"
            
            # Show backup location
            if [[ -f /tmp/dotfiles_backup_path ]]; then
                local backup_path=$(cat /tmp/dotfiles_backup_path)
                print_color $BLUE "💾 Backup saved at: $backup_path"
                rm /tmp/dotfiles_backup_path
            fi
            
            print_color $YELLOW "⚠️  You may need to restart your session for all changes to take effect"
        else
            print_color $YELLOW "Update cancelled"
        fi
    fi
}

# Run if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
