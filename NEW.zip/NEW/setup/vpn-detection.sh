#!/bin/bash

# VPN detection and Waybar integration

setup_vpn_detection() {
    log "Setting up VPN detection..."
    
    detect_installed_vpns
    
    if [[ ${#DETECTED_VPNS[@]} -gt 0 ]]; then
        log "Detected VPNs: ${DETECTED_VPNS[*]}"
        setup_vpn_waybar_module
    else
        log "No VPN clients detected"
    fi
}

detect_installed_vpns() {
    DETECTED_VPNS=()
    
    # Common VPN clients to check
    local vpn_clients=(
        "openvpn:OpenVPN"
        "wireguard-tools:WireGuard"
        "nordvpn-bin:NordVPN"
        "expressvpn:ExpressVPN"
        "surfshark-vpn:Surfshark"
        "protonvpn-cli:ProtonVPN"
        "mullvad-vpn:Mullvad"
        "cyberghostvpn:CyberGhost"
        "pia-vpn:Private Internet Access"
        "strongswan:StrongSwan"
        "openconnect:OpenConnect"
        "networkmanager-openvpn:NetworkManager OpenVPN"
        "networkmanager-vpnc:NetworkManager VPNC"
        "networkmanager-strongswan:NetworkManager StrongSwan"
    )
    
    for vpn_entry in "${vpn_clients[@]}"; do
        IFS=':' read -r package_name display_name <<< "$vpn_entry"
        
        # Check if package is installed
        if pacman -Qi "$package_name" &>/dev/null || command -v "${package_name%-*}" &>/dev/null; then
            DETECTED_VPNS+=("$display_name")
        fi
    done
    
    # Check for custom VPN configurations
    if [[ -d /etc/openvpn ]] && [[ -n "$(ls -A /etc/openvpn 2>/dev/null)" ]]; then
        [[ ! " ${DETECTED_VPNS[*]} " =~ " OpenVPN " ]] && DETECTED_VPNS+=("OpenVPN Config")
    fi
    
    if [[ -d /etc/wireguard ]] && [[ -n "$(ls -A /etc/wireguard 2>/dev/null)" ]]; then
        [[ ! " ${DETECTED_VPNS[*]} " =~ " WireGuard " ]] && DETECTED_VPNS+=("WireGuard Config")
    fi
}

setup_vpn_waybar_module() {
    log "Setting up VPN module for Waybar..."
    
    # Create VPN status script
    cat > ~/.config/waybar/modules/vpn.sh << 'EOF'
#!/bin/bash

# VPN Status Module for Waybar

get_vpn_status() {
    local status=""
    local tooltip=""
    local class=""
    
    # Check various VPN connections
    
    # WireGuard
    if command -v wg &>/dev/null; then
        local wg_interfaces=$(wg show interfaces 2>/dev/null)
        if [[ -n "$wg_interfaces" ]]; then
            for interface in $wg_interfaces; do
                if ip link show "$interface" up &>/dev/null; then
                    status="🔒 WG"
                    tooltip="WireGuard: $interface active"
                    class="connected"
                    break
                fi
            done
        fi
    fi
    
    # OpenVPN
    if [[ -z "$status" ]] && command -v pgrep &>/dev/null; then
        if pgrep -x openvpn &>/dev/null; then
            status="🔒 VPN"
            tooltip="OpenVPN: Connected"
            class="connected"
        fi
    fi
    
    # NordVPN
    if [[ -z "$status" ]] && command -v nordvpn &>/dev/null; then
        local nord_status=$(nordvpn status 2>/dev/null | grep "Status:" | awk '{print $2}')
        if [[ "$nord_status" == "Connected" ]]; then
            local server=$(nordvpn status | grep "Server:" | cut -d' ' -f2-)
            status="🔒 Nord"
            tooltip="NordVPN: $server"
            class="connected"
        fi
    fi
    
    # ProtonVPN
    if [[ -z "$status" ]] && command -v protonvpn-cli &>/dev/null; then
        if protonvpn-cli status | grep -q "Connected"; then
            local server=$(protonvpn-cli status | grep "Server:" | cut -d':' -f2 | xargs)
            status="🔒 Proton"
            tooltip="ProtonVPN: $server"
            class="connected"
        fi
    fi
    
    # ExpressVPN
    if [[ -z "$status" ]] && command -v expressvpn &>/dev/null; then
        if expressvpn status | grep -q "Connected"; then
            local location=$(expressvpn status | grep "Connected to" | cut -d' ' -f3-)
            status="🔒 Express"
            tooltip="ExpressVPN: $location"
            class="connected"
        fi
    fi
    
    # Mullvad
    if [[ -z "$status" ]] && command -v mullvad &>/dev/null; then
        if mullvad status | grep -q "Connected"; then
            local server=$(mullvad status | grep "Connected" | cut -d' ' -f3-)
            status="🔒 Mullvad"
            tooltip="Mullvad: $server"
            class="connected"
        fi
    fi
    
    # NetworkManager VPN connections
    if [[ -z "$status" ]] && command -v nmcli &>/dev/null; then
        local vpn_connections=$(nmcli connection show --active | grep vpn)
        if [[ -n "$vpn_connections" ]]; then
            local vpn_name=$(echo "$vpn_connections" | head -n1 | awk '{print $1}')
            status="🔒 VPN"
            tooltip="NetworkManager VPN: $vpn_name"
            class="connected"
        fi
    fi
    
    # Default disconnected state
    if [[ -z "$status" ]]; then
        status="🔓"
        tooltip="VPN: Disconnected"
        class="disconnected"
    fi
    
    # Output JSON for Waybar
    echo "{\"text\":\"$status\",\"tooltip\":\"$tooltip\",\"class\":\"$class\"}"
}

get_vpn_status
EOF
    
    chmod +x ~/.config/waybar/modules/vpn.sh
    
    # Add VPN module to Waybar config
    add_vpn_to_waybar_config
}

add_vpn_to_waybar_config() {
    local waybar_config="$HOME/.config/waybar/config"
    
    if [[ -f "$waybar_config" ]]; then
        # Check if VPN module already exists
        if ! grep -q "custom/vpn" "$waybar_config"; then
            log "Adding VPN module to Waybar configuration..."
            
            # Add VPN module to modules-right section
            sed -i 's/"modules-right": \[\(.*\)\]/"modules-right": [\1, "custom\/vpn"]/' "$waybar_config"
            
            # Add VPN module configuration
            cat >> "$waybar_config" << 'EOF'
    "custom/vpn": {
        "format": "{}",
        "return-type": "json",
        "exec": "~/.config/waybar/modules/vpn.sh",
        "interval": 5,
        "tooltip": true,
        "on-click": "nm-connection-editor"
    },
EOF
        fi
    fi
}
