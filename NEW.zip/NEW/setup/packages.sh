#!/bin/bash

# Package installation functions

install_base_packages() {
    log "Installing base Hyprland packages..."
    
    local base_packages=(
        # Hyprland and Wayland
        hyprland
        xdg-desktop-portal-hyprland
        xdg-desktop-portal-gtk
        waybar
        rofi-wayland
        dunst
        
        # Terminal and shell
        kitty
        fish
        starship
        
        # File management
        thunar
        thunar-archive-plugin
        file-roller
        
        # Media
        pipewire
        pipewire-alsa
        pipewire-pulse
        wireplumber
        pavucontrol
        
        # Utilities
        grim
        slurp
        wl-clipboard
        brightnessctl
        playerctl
        
        # Fonts
        ttf-font-awesome
        ttf-jetbrains-mono
        noto-fonts
        noto-fonts-emoji
        
        # System tools
        htop
        btop
        neofetch
        tree
        wget
        curl
        git
        
        # Network
        networkmanager
        network-manager-applet
    )
    
    sudo pacman -S --needed --noconfirm "${base_packages[@]}"
    
    # Install AUR helper if not present
    if ! command -v yay &> /dev/null; then
        install_yay
    fi
    
    # AUR packages
    local aur_packages=(
        swww
        waybar-hyprland
        rofi-emoji
        wlogout
        hyprpicker
    )
    
    yay -S --needed --noconfirm "${aur_packages[@]}"
    
    # Optional packages based on user choice
    if [[ "$INSTALL_DEV_TOOLS" =~ ^[Yy]$ ]]; then
        install_dev_tools
    fi
    
    if [[ "$INSTALL_GAMING" =~ ^[Yy]$ ]]; then
        install_gaming_tools
    fi
    
    if [[ "$INSTALL_MULTIMEDIA" =~ ^[Yy]$ ]]; then
        install_multimedia_tools
    fi
}

install_yay() {
    log "Installing yay AUR helper..."
    cd /tmp
    git clone https://aur.archlinux.org/yay.git
    cd yay
    makepkg -si --noconfirm
    cd ~
}

install_dev_tools() {
    log "Installing development tools..."
    local dev_packages=(
        code
        docker
        docker-compose
        nodejs
        npm
        python-pip
        rust
        go
    )
    
    sudo pacman -S --needed --noconfirm "${dev_packages[@]}"
}

install_gaming_tools() {
    log "Installing gaming tools..."
    local gaming_packages=(
        steam
        lutris
        wine
        winetricks
        gamemode
        mangohud
    )
    
    sudo pacman -S --needed --noconfirm "${gaming_packages[@]}"
}

install_multimedia_tools() {
    log "Installing multimedia tools..."
    local multimedia_packages=(
        obs-studio
        gimp
        inkscape
        blender
        vlc
        audacity
    )
    
    sudo pacman -S --needed --noconfirm "${multimedia_packages[@]}"
}