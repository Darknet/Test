#!/bin/bash

# Graphics configuration functions

configure_graphics() {
    local choice=$1
    
    case $choice in
        1)
            configure_nvidia
            ;;
        2)
            configure_amd
            ;;
        3)
            configure_intel
            ;;
        4)
            configure_hybrid
            ;;
        5)
            auto_configure_graphics
            ;;
        *)
            warn "Invalid graphics option, using auto-detect"
            auto_configure_graphics
            ;;
    esac
}

auto_configure_graphics() {
    log "Auto-detecting graphics configuration..."
    
    if [[ $GPU_NVIDIA -gt 0 ]]; then
        if [[ $HYBRID_GPU == true ]]; then
            configure_hybrid
        else
            configure_nvidia
        fi
    elif [[ $GPU_AMD -gt 0 ]]; then
        configure_amd
    elif [[ $GPU_INTEL -gt 0 ]]; then
        configure_intel
    else
        warn "No supported GPU detected, using generic configuration"
    fi
}

configure_nvidia() {
    log "Configuring NVIDIA graphics..."
    
    local nvidia_packages=(
        nvidia
        nvidia-utils
        nvidia-settings
        libva
        libva-nvidia-driver-git
    )
    
    sudo pacman -S --needed --noconfirm nvidia nvidia-utils nvidia-settings libva
    yay -S --needed --noconfirm libva-nvidia-driver-git
    
    # Add NVIDIA environment variables
    cat >> ~/.config/hypr/hyprland.conf << EOF

# NVIDIA specific configuration
env = LIBVA_DRIVER_NAME,nvidia
env = XDG_SESSION_TYPE,wayland
env = GBM_BACKEND,nvidia-drm
env = __GLX_VENDOR_LIBRARY_NAME,nvidia
env = WLR_NO_HARDWARE_CURSORS,1
EOF
}

configure_amd() {
    log "Configuring AMD graphics..."
    
    local amd_packages=(
        mesa
        lib32-mesa
        xf86-video-amdgpu
        vulkan-radeon
        lib32-vulkan-radeon
        libva-mesa-driver
        lib32-libva-mesa-driver
    )
    
    sudo pacman -S --needed --noconfirm "${amd_packages[@]}"
}

configure_intel() {
    log "Configuring Intel graphics..."
    
    local intel_packages=(
        mesa
        lib32-mesa
        vulkan-intel
        lib32-vulkan-intel
        libva-intel-driver
        lib32-libva-intel-driver
    )
    
    sudo pacman -S --needed --noconfirm "${intel_packages[@]}"
}

configure_hybrid() {
    log "Configuring hybrid graphics..."
    
    # Install both NVIDIA and Intel/AMD drivers
    configure_nvidia
    
    if [[ $GPU_INTEL -gt 0 ]]; then
        configure_intel
    elif [[ $GPU_AMD -gt 0 ]]; then
        configure_amd
    fi
    
    # Install optimus manager for hybrid graphics
    yay -S --needed --noconfirm optimus-manager optimus-manager-qt
    
    # Enable optimus-manager service
    sudo systemctl enable optimus-manager.service
    
    log "Hybrid graphics configured. You can switch between GPUs using optimus-manager"
}