#!/bin/bash

# Waydroid installation and configuration

install_waydroid() {
    log "Installing Waydroid..."
    
    # Install required packages
    local waydroid_packages=(
        waydroid
        python-pyclip
        lxc
    )
    
    yay -S --needed --noconfirm "${waydroid_packages[@]}"
    
    # Enable required services
    sudo systemctl enable --now waydroid-container.service
    
    # Initialize Waydroid
    log "Initializing Waydroid (this may take a while)..."
    sudo waydroid init
    
    # Start Waydroid session
    waydroid session start &
    
    # Add Waydroid to Waybar if configured
    add_waydroid_to_waybar
    
    log "Waydroid installation completed"
    log "You can start Android apps with 'waydroid app launch <package_name>'"
}

add_waydroid_to_waybar() {
    local waybar_config="$HOME/.config/waybar/config"
    
    if [[ -f "$waybar_config" ]]; then
        log "Adding Waydroid module to Waybar..."
        
        # Add Waydroid module configuration
        cat >> "$waybar_config" << 'EOF'
    "custom/waydroid": {
        "format": "🤖 {}",
        "exec": "~/.config/waybar/modules/waydroid.sh",
        "interval": 10,
        "tooltip": true,
        "on-click": "waydroid show-full-ui"
    },
EOF
    fi
}