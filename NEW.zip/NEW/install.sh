#!/bin/bash

# Enhanced Arch Hyprland Installation Script
# Combining best features from JaKooLit and mylinuxforwork

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Log function
log() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        error "This script should not be run as root"
        exit 1
    fi
}

# System detection
detect_system() {
    log "Detecting system configuration..."
    
    # Detect if laptop
    if [[ -d /proc/acpi/battery ]] || [[ -n $(ls /sys/class/power_supply/BAT* 2>/dev/null) ]]; then
        IS_LAPTOP=true
        log "Laptop detected"
    else
        IS_LAPTOP=false
        log "Desktop system detected"
    fi
    
    # Detect GPU
    GPU_NVIDIA=$(lspci | grep -i nvidia | wc -l)
    GPU_AMD=$(lspci | grep -i amd | wc -l)
    GPU_INTEL=$(lspci | grep -i intel | wc -l)
    
    if [[ $GPU_NVIDIA -gt 0 && ($GPU_AMD -gt 0 || $GPU_INTEL -gt 0) ]]; then
        HYBRID_GPU=true
        log "Hybrid GPU configuration detected"
    else
        HYBRID_GPU=false
    fi
}

# User prompts
user_prompts() {
    echo -e "${BLUE}=== Enhanced Arch Hyprland Setup ===${NC}"
    echo
    
    # Graphics configuration
    echo "Graphics Configuration:"
    echo "1) NVIDIA only"
    echo "2) AMD only" 
    echo "3) Intel only"
    echo "4) Hybrid (NVIDIA + Intel/AMD)"
    echo "5) Auto-detect"
    read -p "Select graphics option [5]: " GRAPHICS_CHOICE
    GRAPHICS_CHOICE=${GRAPHICS_CHOICE:-5}
    
    # Waydroid installation
    read -p "Install Waydroid for Android app support? [y/N]: " INSTALL_WAYDROID
    INSTALL_WAYDROID=${INSTALL_WAYDROID:-n}
    
    # Additional features
    read -p "Install development tools? [y/N]: " INSTALL_DEV_TOOLS
    INSTALL_DEV_TOOLS=${INSTALL_DEV_TOOLS:-n}
    
    read -p "Install gaming tools? [y/N]: " INSTALL_GAMING
    INSTALL_GAMING=${INSTALL_GAMING:-n}
    
    read -p "Install multimedia tools? [y/N]: " INSTALL_MULTIMEDIA
    INSTALL_MULTIMEDIA=${INSTALL_MULTIMEDIA:-n}
}

# Main installation function
main() {
    check_root
    detect_system
    user_prompts
    
    log "Starting installation process..."
    
    # Update system
    log "Updating system packages..."
    sudo pacman -Syu --noconfirm
    
    # Install base packages
    source "${SCRIPT_DIR}/setup/packages.sh"
    install_base_packages
    
    # Configure graphics
    source "${SCRIPT_DIR}/setup/graphics.sh"
    configure_graphics "$GRAPHICS_CHOICE"
    
    # Install Waydroid if requested
    if [[ "$INSTALL_WAYDROID" =~ ^[Yy]$ ]]; then
        source "${SCRIPT_DIR}/setup/waydroid.sh"
        install_waydroid
    fi
    
    # Setup dotfiles
    setup_dotfiles
    
    # Configure VPN detection
    source "${SCRIPT_DIR}/setup/vpn-detection.sh"
    setup_vpn_detection
    
    log "Installation completed successfully!"
    log "Please reboot your system to start using Hyprland"
}

# Setup dotfiles
setup_dotfiles() {
    log "Setting up configuration files..."
    
    # Create config directories
    mkdir -p ~/.config/{hypr,waybar,rofi,kitty,scripts}
    
    # Copy configuration files
    cp -r "${SCRIPT_DIR}/config/"* ~/.config/
    
    # Make scripts executable
    chmod +x ~/.config/scripts/*
    chmod +x ~/.config/waybar/modules/*
    
    log "Dotfiles configured successfully"
}

# Run main function
main "$@"