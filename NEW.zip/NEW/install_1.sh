#!/bin/bash

# Enhanced Hyprland Setup Installation Script

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Function to print colored output
print_color() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Function to print section headers
print_header() {
    echo
    print_color $PURPLE "=================================="
    print_color $PURPLE "$1"
    print_color $PURPLE "=================================="
    echo
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to detect distribution
detect_distro() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        echo $ID
    else
        echo "unknown"
    fi
}

# Function to install packages based on distribution
install_packages() {
    local distro=$(detect_distro)
    local packages="$1"
    
    case $distro in
        "arch"|"manjaro"|"endeavouros")
            print_color $BLUE "Installing packages with pacman/yay..."
            if command_exists yay; then
                yay -S --needed --noconfirm $packages
            elif command_exists paru; then
                paru -S --needed --noconfirm $packages
            else
                sudo pacman -S --needed --noconfirm $packages
            fi
            ;;
        "ubuntu"|"debian"|"pop")
            print_color $BLUE "Installing packages with apt..."
            sudo apt update
            sudo apt install -y $packages
            ;;
        "fedora")
            print_color $BLUE "Installing packages with dnf..."
            sudo dnf install -y $packages
            ;;
        *)
            print_color $RED "Unsupported distribution: $distro"
            print_color $YELLOW "Please install packages manually"
            return 1
            ;;
    esac
}

# Function to install AUR helper (Arch-based only)
install_aur_helper() {
    local distro=$(detect_distro)
    
    if [[ "$distro" == "arch" || "$distro" == "manjaro" || "$distro" == "endeavouros" ]]; then
        if ! command_exists yay && ! command_exists paru; then
            print_color $YELLOW "Installing yay AUR helper..."
            
            # Install base-devel and git if not present
            sudo pacman -S --needed --noconfirm base-devel git
            
            # Clone and install yay
            cd /tmp
            git clone https://aur.archlinux.org/yay.git
            cd yay
            makepkg -si --noconfirm
            cd ~
            rm -rf /tmp/yay
            
            print_color $GREEN "yay installed successfully!"
        fi
    fi
}

# Function to create directories
create_directories() {
    print_header "Creating Directories"
    
    local dirs=(
        "$HOME/.config"
        "$HOME/.config/hypr"
        "$HOME/.config/waybar"
        "$HOME/.config/waybar/modules"
        "$HOME/.config/rofi"
        "$HOME/.config/rofi/themes"
        "$HOME/.config/kitty"
        "$HOME/.config/mako"
        "$HOME/.config/scripts"
        "$HOME/Pictures/Screenshots"
        "$HOME/Pictures/Wallpapers"
        "$HOME/.local/bin"
    )
    
    for dir in "${dirs[@]}"; do
        if [[ ! -d "$dir" ]]; then
            mkdir -p "$dir"
            print_color $GREEN "Created: $dir"
        else
            print_color $YELLOW "Already exists: $dir"
        fi
    done
}

# Function to backup existing configs
backup_configs() {
    print_header "Backing Up Existing Configurations"
    
    local backup_dir="$HOME/.config/backup_$(date +%Y%m%d_%H%M%S)"
    local configs_to_backup=(
        "$HOME/.config/hypr"
        "$HOME/.config/waybar"
        "$HOME/.config/rofi"
        "$HOME/.config/kitty"
        "$HOME/.config/mako"
    )
    
    local backup_needed=false
    
    for config in "${configs_to_backup[@]}"; do
        if [[ -d "$config" ]] && [[ -n "$(ls -A "$config" 2>/dev/null)" ]]; then
            backup_needed=true
            break
        fi
    done
    
    if [[ "$backup_needed" == true ]]; then
        mkdir -p "$backup_dir"
        
        for config in "${configs_to_backup[@]}"; do
            if [[ -d "$config" ]] && [[ -n "$(ls -A "$config" 2>/dev/null)" ]]; then
                local config_name=$(basename "$config")
                cp -r "$config" "$backup_dir/$config_name"
                print_color $GREEN "Backed up: $config -> $backup_dir/$config_name"
            fi
        done
        
        print_color $CYAN "Backup created at: $backup_dir"
    else
        print_color $YELLOW "No existing configurations found to backup"
    fi
}

# Function to install core packages
install_core_packages() {
    print_header "Installing Core Packages"
    
    local distro=$(detect_distro)
    local core_packages=""
    
    case $distro in
        "arch"|"manjaro"|"endeavouros")
            core_packages="hyprland waybar rofi kitty mako grim slurp swww wf-recorder xdg-desktop-portal-hyprland polkit-kde-agent qt5-wayland qt6-wayland"
            ;;
        "ubuntu"|"debian"|"pop")
            core_packages="waybar rofi kitty mako-notifier grim slurp wf-recorder xdg-desktop-portal-wlr"
            print_color $YELLOW "Note: Hyprland may need to be compiled from source on Debian/Ubuntu"
            ;;
        "fedora")
            core_packages="hyprland waybar rofi kitty mako grim slurp wf-recorder xdg-desktop-portal-hyprland"
            ;;
    esac
    
    if [[ -n "$core_packages" ]]; then
        install_packages "$core_packages"
    fi
}

# Function to install additional packages
install_additional_packages() {
    print_header "Installing Additional Packages"
    
    local distro=$(detect_distro)
    local additional_packages=""
    
    case $distro in
        "arch"|"manjaro"|"endeavouros")
            additional_packages="ttf-jetbrains-mono-nerd noto-fonts noto-fonts-emoji thunar firefox pavucontrol networkmanager network-manager-applet bluez bluez-utils pipewire pipewire-pulse pipewire-alsa wireplumber python-pywal jq bc playerctl brightnessctl"
            ;;
        "ubuntu"|"debian"|"pop")
            additional_packages="fonts-jetbrains-mono fonts-noto fonts-noto-color-emoji thunar firefox pavucontrol network-manager-gnome bluez pulseaudio python3-pywal jq bc playerctl brightnessctl"
            ;;
        "fedora")
            additional_packages="jetbrains-mono-fonts google-noto-fonts google-noto-emoji-fonts thunar firefox pavucontrol NetworkManager-applet bluez pipewire pipewire-pulseaudio python3-pywal jq bc playerctl brightnessctl"
            ;;
    esac
    
    if [[ -n "$additional_packages" ]]; then
        install_packages "$additional_packages"
    fi
}

# Function to install AUR packages (Arch only)
install_aur_packages() {
    local distro=$(detect_distro)
    
    if [[ "$distro" == "arch" || "$distro" == "manjaro" || "$distro" == "endeavouros" ]]; then
        print_header "Installing AUR Packages"
        
        local aur_packages="swww-git hyprpicker-git wlogout"
        
        if command_exists yay || command_exists paru; then
            install_packages "$aur_packages"
        else
            print_color $YELLOW "No AUR helper found, skipping AUR packages"
        fi
    fi
}

# Function to copy configuration files
copy_configs() {
    print_header "Copying Configuration Files"
    
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    # Copy Hyprland config
    if [[ -f "$script_dir/config/hypr/hyprland.conf" ]]; then
        cp "$script_dir/config/hypr/hyprland.conf" "$HOME/.config/hypr/"
        print_color $GREEN "Copied Hyprland configuration"
    fi
    
    # Copy Waybar config
    if [[ -d "$script_dir/config/waybar" ]]; then
        cp -r "$script_dir/config/waybar/"* "$HOME/.config/waybar/"
        print_color $GREEN "Copied Waybar configuration"
    fi
    
    # Copy Rofi config
    if [[ -d "$script_dir/config/rofi" ]]; then
        cp -r "$script_dir/config/rofi/"* "$HOME/.config/rofi/"
        print_color $GREEN "Copied Rofi configuration"
    fi
    
    # Copy Kitty config
    if [[ -f "$script_dir/config/kitty/kitty.conf" ]]; then
        cp "$script_dir/config/kitty/kitty.conf" "$HOME/.config/kitty/"
        print_color $GREEN "Copied Kitty configuration"
    fi
    
    # Copy Mako config
    if [[ -f "$script_dir/config/mako/config" ]]; then
        cp "$script_dir/config/mako/config" "$HOME/.config/mako/"
        print_color $GREEN "Copied Mako configuration"
    fi
    
    # Copy scripts
    if [[ -d "$script_dir/config/scripts" ]]; then
        cp -r "$script_dir/config/scripts/"* "$HOME/.config/scripts/"
        chmod +x "$HOME/.config/scripts/"*.sh
        print_color $GREEN "Copied and made scripts executable"
    fi
}

# Function to setup systemd services
setup_services() {
    print_header "Setting Up System Services"
    
    # Enable NetworkManager
    if systemctl list-unit-files | grep -q NetworkManager.service; then
        sudo systemctl enable NetworkManager.service
        print_color $GREEN "Enabled NetworkManager"
    fi
    
    # Enable Bluetooth
    if systemctl list-unit-files | grep -q bluetooth.service; then
        sudo systemctl enable bluetooth.service
        print_color $GREEN "Enabled Bluetooth"
    fi
    
    # Enable PipeWire (if available)
    if systemctl --user list-unit-files | grep -q pipewire.service; then
        systemctl --user enable pipewire.service pipewire-pulse.service wireplumber.service
        print_color $GREEN "Enabled PipeWire audio services"
    fi
}

# Function to download sample wallpapers
download_wallpapers() {
    print_header "Downloading Sample Wallpapers"
    
    local wallpaper_urls=(
        "https://raw.githubusercontent.com/catppuccin/wallpapers/main/landscapes/tropic_island_day.png"
        "https://raw.githubusercontent.com/catppuccin/wallpapers/main/landscapes/tropic_island_night.png"
        "https://raw.githubusercontent.com/catppuccin/wallpapers/main/landscapes/mountain.png"
    )
    
    for url in "${wallpaper_urls[@]}"; do
        local filename=$(basename "$url")
        local filepath="$HOME/Pictures/Wallpapers/$filename"
        
        if [[ ! -f "$filepath" ]]; then
            if command_exists wget; then
                wget -q -O "$filepath" "$url" && print_color $GREEN "Downloaded: $filename"
            elif command_exists curl; then
                curl -s -o "$filepath" "$url" && print_color $GREEN "Downloaded: $filename"
            else
                print_color $YELLOW "wget or curl not found, skipping wallpaper downloads"
                break
            fi
        else
            print_color $YELLOW "Already exists: $filename"
        fi
    done
}

# Function to set up environment variables
setup_environment() {
    print_header "Setting Up Environment Variables"
    
    local env_file="$HOME/.config/hypr/env.conf"
    
    cat > "$env_file" << 'EOF'
# Environment variables for Hyprland

# XDG
env = XDG_CURRENT_DESKTOP,Hyprland
env = XDG_SESSION_TYPE,wayland
env = XDG_SESSION_DESKTOP,Hyprland

# Qt
env = QT_QPA_PLATFORM,wayland;xcb
env = QT_QPA_PLATFORMTHEME,qt5ct
env = QT_WAYLAND_DISABLE_WINDOWDECORATION,1
env = QT_AUTO_SCREEN_SCALE_FACTOR,1

# GTK
env = GDK_BACKEND,wayland,x11
env = GTK_THEME,Adwaita:dark

# Mozilla
env = MOZ_ENABLE_WAYLAND,1

# NVIDIA (uncomment if using NVIDIA)
# env = LIBVA_DRIVER_NAME,nvidia
# env = GBM_BACKEND,nvidia-drm
# env = __GLX_VENDOR_LIBRARY_NAME,nvidia
# env = WLR_NO_HARDWARE_CURSORS,1

# Cursor
env = XCURSOR_SIZE,24
env = XCURSOR_THEME,Adwaita

# Other
env = EDITOR,nano
env = BROWSER,firefox
env = TERMINAL,kitty
EOF
    
    print_color $GREEN "Created environment configuration"
}

# Function to create desktop entry
create_desktop_entry() {
    print_header "Creating Desktop Entry"
    
    local desktop_file="$HOME/.local/share/applications/hyprland.desktop"
    mkdir -p "$(dirname "$desktop_file")"
    
    cat > "$desktop_file" << 'EOF'
[Desktop Entry]
Name=Hyprland
Comment=An intelligent dynamic tiling Wayland compositor
Exec=Hyprland
Type=Application
EOF
    
    print_color $GREEN "Created Hyprland desktop entry"
}

# Function to show post-installation instructions
show_post_install() {
    print_header "Installation Complete!"
    
    print_color $GREEN "✅ Hyprland setup has been installed successfully!"
    echo
    print_color $CYAN "Next steps:"
    print_color $YELLOW "1. Log out of your current session"
    print_color $YELLOW "2. Select 'Hyprland' from your display manager"
    print_color $YELLOW "3. Log in to start using Hyprland"
    echo
    print_color $CYAN "Key bindings:"
    print_color $YELLOW "• Super + Return: Open terminal (Kitty)"
    print_color $YELLOW "• Super + D: Application launcher (Rofi)"
    print_color $YELLOW "• Super + Q: Close window"
    print_color $YELLOW "• Super + M: Exit Hyprland"
    print_color $YELLOW "• Super + V: Toggle floating"
    print_color $YELLOW "• Super + F: Toggle fullscreen"
    print_color $YELLOW "• Super + S: Take screenshot"
    print_color $YELLOW "• Super + Shift + S: Screenshot area"
    print_color $YELLOW "• Super + W: Change wallpaper"
    echo
    print_color $CYAN "Configuration files location:"
    print_color $YELLOW "• Hyprland: ~/.config/hypr/"
    print_color $YELLOW "• Waybar: ~/.config/waybar/"
    print_color $YELLOW "• Rofi: ~/.config/rofi/"
    print_color $YELLOW "• Scripts: ~/.config/scripts/"
    echo
    print_color $CYAN "Useful commands:"
    print_color $YELLOW "• hyprctl reload: Reload Hyprland config"
    print_color $YELLOW "• ~/.config/scripts/wallpaper.sh --menu: Wallpaper menu"
    print_color $YELLOW "• ~/.config/scripts/screenshot.sh --help: Screenshot help"
    echo
    print_color $RED "⚠️  Important notes:"
    print_color $YELLOW "• Make sure your display manager supports Wayland sessions"
    print_color $YELLOW "• NVIDIA users may need additional configuration"
    print_color $YELLOW "• Some applications may need XWayland for compatibility"
    echo
}

# Function to handle errors
handle_error() {
    print_color $RED "❌ An error occurred during installation!"
    print_color $YELLOW "Please check the output above for details."
    print_color $YELLOW "You can try running the script again or install components manually."
    exit 1
}

# Function to check system requirements
check_requirements() {
    print_header "Checking System Requirements"
    
    # Check if running on Wayland-compatible system
    if [[ -z "$XDG_SESSION_TYPE" ]]; then
        print_color $YELLOW "Cannot detect session type"
    elif [[ "$XDG_SESSION_TYPE" == "x11" ]]; then
        print_color $YELLOW "Currently running X11 session"
        print_color $YELLOW "Hyprland requires Wayland support"
    fi
    
    # Check for required commands
    local required_commands=("git" "make" "gcc")
    local missing_commands=()
    
    for cmd in "${required_commands[@]}"; do
        if ! command_exists "$cmd"; then
            missing_commands+=("$cmd")
        fi
    done
    
    if [[ ${#missing_commands[@]} -gt 0 ]]; then
        print_color $RED "Missing required commands: ${missing_commands[*]}"
        print_color $YELLOW "Installing build essentials..."
        
        local distro=$(detect_distro)
        case $distro in
            "arch"|"manjaro"|"endeavouros")
                sudo pacman -S --needed --noconfirm base-devel git
                ;;
            "ubuntu"|"debian"|"pop")
                sudo apt update && sudo apt install -y build-essential git
                ;;
            "fedora")
                sudo dnf groupinstall -y "Development Tools" && sudo dnf install -y git
                ;;
        esac
    fi
    
    print_color $GREEN "System requirements check completed"
}

# Function to prompt user for installation options
prompt_installation_options() {
    print_header "Installation Options"
    
    echo "This script will install and configure:"
    echo "• Hyprland (dynamic tiling Wayland compositor)"
    echo "• Waybar (status bar)"
    echo "• Rofi (application launcher)"
    echo "• Kitty (terminal emulator)"
    echo "• Mako (notification daemon)"
    echo "• Various utilities and scripts"
    echo
    
    read -p "Do you want to continue? (y/N): " -n 1 -r
    echo
    
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_color $YELLOW "Installation cancelled by user"
        exit 0
    fi
    
    echo
    read -p "Create backup of existing configurations? (Y/n): " -n 1 -r
    echo
    
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        BACKUP_CONFIGS=true
    else
        BACKUP_CONFIGS=false
    fi
    
    echo
    read -p "Download sample wallpapers? (Y/n): " -n 1 -r
    echo
    
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        DOWNLOAD_WALLPAPERS=true
    else
        DOWNLOAD_WALLPAPERS=false
    fi
}

# Main installation function
main() {
    # Set error handler
    trap handle_error ERR
    
    print_color $CYAN "🚀 Enhanced Hyprland Setup Installer"
    print_color $CYAN "====================================="
    echo
    
    # Check if running as root
    if [[ $EUID -eq 0 ]]; then
        print_color $RED "❌ This script should not be run as root!"
        print_color $YELLOW "Please run as a regular user with sudo privileges."
        exit 1
    fi
    
    # Check system requirements
    check_requirements
    
    # Prompt for installation options
    prompt_installation_options
    
    # Detect distribution
    local distro=$(detect_distro)
    print_color $BLUE "Detected distribution: $distro"
    echo
    
    # Start installation process
    print_color $GREEN "🔧 Starting installation process..."
    
    # Create directories
    create_directories
    
    # Backup existing configs if requested
    if [[ "$BACKUP_CONFIGS" == true ]]; then
        backup_configs
    fi
    
    # Install AUR helper (Arch-based systems)
    install_aur_helper
    
    # Install packages
    install_core_packages
    install_additional_packages
    install_aur_packages
    
    # Copy configuration files
    copy_configs
    
    # Setup environment
    setup_environment
    
    # Setup system services
    setup_services
    
    # Create desktop entry
    create_desktop_entry
    
    # Download wallpapers if requested
    if [[ "$DOWNLOAD_WALLPAPERS" == true ]]; then
        download_wallpapers
    fi
    
    # Show post-installation instructions
    show_post_install
}

# Run main function if script is executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
