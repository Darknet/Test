#!/bin/bash

# WiFi Menu Script for Rofi

# Colors for notifications
COLOR_SUCCESS="#a6e3a1"
COLOR_ERROR="#f38ba8"
COLOR_WARNING="#f9e2af"
COLOR_INFO="#89b4fa"

# Function to send notifications
notify() {
    local message="$1"
    local type="${2:-info}"
    local urgency="normal"
    local color="$COLOR_INFO"
    
    case "$type" in
        "success") color="$COLOR_SUCCESS" ;;
        "error") color="$COLOR_ERROR"; urgency="critical" ;;
        "warning") color="$COLOR_WARNING" ;;
    esac
    
    notify-send "WiFi Manager" "$message" \
        -u "$urgency" \
        -t 3000 \
        -a "WiFi Manager"
}

# Function to get WiFi status
get_wifi_status() {
    if nmcli radio wifi | grep -q "enabled"; then
        echo "enabled"
    else
        echo "disabled"
    fi
}

# Function to get current connection
get_current_connection() {
    nmcli -t -f NAME connection show --active | grep -v "lo" | head -n1
}

# Function to scan for networks
scan_networks() {
    nmcli device wifi rescan 2>/dev/null
    sleep 2
    nmcli -t -f SSID,SECURITY,SIGNAL device wifi list | sort -t: -k3 -nr
}

# Function to connect to network
connect_network() {
    local ssid="$1"
    local security="$2"
    
    if [[ "$security" == "--" ]]; then
        # Open network
        if nmcli device wifi connect "$ssid"; then
            notify "Connected to $ssid" "success"
        else
            notify "Failed to connect to $ssid" "error"
        fi
    else
        # Secured network - prompt for password
        local password=$(rofi -dmenu -p "Password for $ssid" -password -theme ~/.config/rofi/themes/catppuccin-mocha.rasi)
        
        if [[ -n "$password" ]]; then
            if nmcli device wifi connect "$ssid" password "$password"; then
                notify "Connected to $ssid" "success"
            else
                notify "Failed to connect to $ssid" "error"
            fi
        fi
    fi
}

# Function to disconnect from current network
disconnect_current() {
    local current=$(get_current_connection)
    if [[ -n "$current" ]]; then
        if nmcli connection down "$current"; then
            notify "Disconnected from $current" "success"
        else
            notify "Failed to disconnect from $current" "error"
        fi
    else
        notify "No active connection to disconnect" "warning"
    fi
}

# Function to toggle WiFi
toggle_wifi() {
    local status=$(get_wifi_status)
    
    if [[ "$status" == "enabled" ]]; then
        nmcli radio wifi off
        notify "WiFi disabled" "warning"
    else
        nmcli radio wifi on
        notify "WiFi enabled" "success"
    fi
}

# Function to show saved connections
show_saved_connections() {
    local connections=$(nmcli -t -f NAME connection show | grep -v "lo")
    
    if [[ -z "$connections" ]]; then
        notify "No saved connections found" "info"
        return
    fi
    
    local selected=$(echo "$connections" | rofi -dmenu -i -p "Saved Connections" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi)
    
    if [[ -n "$selected" ]]; then
        local action=$(echo -e "Connect\nDelete\nEdit" | rofi -dmenu -i -p "Action for $selected" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi)
        
        case "$action" in
            "Connect")
                if nmcli connection up "$selected"; then
                    notify "Connected to $selected" "success"
                else
                    notify "Failed to connect to $selected" "error"
                fi
                ;;
            "Delete")
                if nmcli connection delete "$selected"; then
                    notify "Deleted connection $selected" "success"
                else
                    notify "Failed to delete $selected" "error"
                fi
                ;;
            "Edit")
                nm-connection-editor &
                ;;
        esac
    fi
}

# Function to show network details
show_network_details() {
    local current=$(get_current_connection)
    if [[ -n "$current" ]]; then
        local details=$(nmcli connection show "$current")
        echo "$details" | rofi -dmenu -i -p "Connection Details: $current" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi
    else
        notify "No active connection" "warning"
    fi
}

# Main menu function
show_main_menu() {
    local wifi_status=$(get_wifi_status)
    local current_connection=$(get_current_connection)
    local status_icon=""
    local connection_info=""
    
    if [[ "$wifi_status" == "enabled" ]]; then
        status_icon="📶"
        if [[ -n "$current_connection" ]]; then
            connection_info=" Connected to: $current_connection"
        else
            connection_info=" WiFi enabled, not connected"
        fi
    else
        status_icon="📵"
        connection_info=" WiFi disabled"
    fi
    
    local menu_options=""
    
    if [[ "$wifi_status" == "enabled" ]]; then
        menu_options+="🔍 Scan Networks\n"
        menu_options+="💾 Saved Connections\n"
        if [[ -n "$current_connection" ]]; then
            menu_options+="🔌 Disconnect\n"
            menu_options+="ℹ️ Connection Details\n"
        fi
        menu_options+="📵 Disable WiFi\n"
    else
        menu_options+="📶 Enable WiFi\n"
    fi
    
    menu_options+="⚙️ Network Settings\n"
    menu_options+="🔄 Refresh"
    
    local selected=$(echo -e "$menu_options" | rofi -dmenu -i -p "$status_icon WiFi Menu$connection_info" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi)
    
    case "$selected" in
        "🔍 Scan Networks")
            show_network_list
            ;;
        "💾 Saved Connections")
            show_saved_connections
            ;;
        "🔌 Disconnect")
            disconnect_current
            ;;
        "ℹ️ Connection Details")
            show_network_details
            ;;
        "📵 Disable WiFi"|"📶 Enable WiFi")
            toggle_wifi
            ;;
        "⚙️ Network Settings")
            nm-connection-editor &
            ;;
        "🔄 Refresh")
            show_main_menu
            ;;
    esac
}

# Function to show available networks
show_network_list() {
    notify "Scanning for networks..." "info"
    
    local networks=$(scan_networks)
    
    if [[ -z "$networks" ]]; then
        notify "No networks found" "warning"
        return
    fi
    
    local formatted_networks=""
    local network_data=()
    
    while IFS=':' read -r ssid security signal; do
        if [[ -n "$ssid" && "$ssid" != "--" ]]; then
            local security_icon=""
            local signal_icon=""
            
            # Security icon
            if [[ "$security" == "--" ]]; then
                security_icon="🔓"
            else
                security_icon="🔒"
            fi
            
            # Signal strength icon
            if [[ "$signal" -ge 75 ]]; then
                signal_icon="📶"
            elif [[ "$signal" -ge 50 ]]; then
                signal_icon="📶"
            elif [[ "$signal" -ge 25 ]]; then
                signal_icon="📶"
            else
                signal_icon="📶"
            fi
            
            formatted_networks+="$security_icon $signal_icon $ssid ($signal%)\n"
            network_data+=("$ssid:$security")
        fi
    done <<< "$networks"
    
    if [[ -z "$formatted_networks" ]]; then
        notify "No valid networks found" "warning"
        return
    fi
    
    local selected=$(echo -e "$formatted_networks" | rofi -dmenu -i -p "Select Network" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi)
    
    if [[ -n "$selected" ]]; then
        # Extract SSID from selection
        local ssid=$(echo "$selected" | sed 's/^[🔓🔒] [📶] \(.*\) ([0-9]*%)$/\1/')
        
        # Find corresponding network data
        for data in "${network_data[@]}"; do
            local net_ssid=$(echo "$data" | cut -d':' -f1)
            local net_security=$(echo "$data" | cut -d':' -f2)
            
            if [[ "$net_ssid" == "$ssid" ]]; then
                connect_network "$ssid" "$net_security"
                break
            fi
        done
    fi
}

# Check if NetworkManager is available
if ! command -v nmcli &> /dev/null; then
    notify "NetworkManager not found" "error"
    exit 1
fi

# Main execution
show_main_menu