#!/bin/bash

# Enhanced Screenshot Script for Hyprland

SCREENSHOT_DIR="$HOME/Pictures/Screenshots"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")

# Create screenshot directory if it doesn't exist
mkdir -p "$SCREENSHOT_DIR"

# Function to send notification
notify_screenshot() {
    local file="$1"
    local mode="$2"
    
    if [[ -f "$file" ]]; then
        notify-send "Screenshot Captured" "Saved as $(basename "$file")" \
            -i "$file" \
            -t 3000 \
            -a "Screenshot" \
            --action="open=Open" \
            --action="folder=Open Folder" \
            --action="copy=Copy to Clipboard"
    else
        notify-send "Screenshot Failed" "Could not save screenshot" \
            -u critical \
            -t 3000 \
            -a "Screenshot"
    fi
}

# Function to copy to clipboard
copy_to_clipboard() {
    local file="$1"
    if command -v wl-copy &> /dev/null; then
        wl-copy < "$file"
        notify-send "Screenshot Copied" "Image copied to clipboard" \
            -t 2000 \
            -a "Screenshot"
    fi
}

# Function to take full screen screenshot
screenshot_full() {
    local file="$SCREENSHOT_DIR/screenshot_full_$TIMESTAMP.png"
    
    if command -v grim &> /dev/null; then
        grim "$file"
        notify_screenshot "$file" "full"
    else
        notify-send "Error" "grim not found. Please install grim for screenshots." \
            -u critical \
            -t 5000
        exit 1
    fi
}

# Function to take area screenshot
screenshot_area() {
    local file="$SCREENSHOT_DIR/screenshot_area_$TIMESTAMP.png"
    
    if command -v grim &> /dev/null && command -v slurp &> /dev/null; then
        local area=$(slurp)
        if [[ -n "$area" ]]; then
            grim -g "$area" "$file"
            notify_screenshot "$file" "area"
        fi
    else
        notify-send "Error" "grim and slurp are required for area screenshots." \
            -u critical \
            -t 5000
        exit 1
    fi
}

# Function to take window screenshot
screenshot_window() {
    local file="$SCREENSHOT_DIR/screenshot_window_$TIMESTAMP.png"
    
    if command -v grim &> /dev/null && command -v hyprctl &> /dev/null; then
        # Get active window geometry
        local window_info=$(hyprctl activewindow -j)
        local x=$(echo "$window_info" | jq -r '.at[0]')
        local y=$(echo "$window_info" | jq -r '.at[1]')
        local width=$(echo "$window_info" | jq -r '.size[0]')
        local height=$(echo "$window_info" | jq -r '.size[1]')
        
        if [[ "$x" != "null" && "$y" != "null" && "$width" != "null" && "$height" != "null" ]]; then
            grim -g "${x},${y} ${width}x${height}" "$file"
            notify_screenshot "$file" "window"
        else
            notify-send "Error" "Could not get active window information" \
                -u critical \
                -t 3000
        fi
    else
        notify-send "Error" "grim and hyprctl are required for window screenshots." \
            -u critical \
            -t 5000
        exit 1
    fi
}

# Function to take screenshot with delay
screenshot_delay() {
    local delay="$1"
    local mode="$2"
    
    notify-send "Screenshot Delayed" "Taking screenshot in $delay seconds..." \
        -t $((delay * 1000)) \
        -a "Screenshot"
    
    sleep "$delay"
    
    case "$mode" in
        "full") screenshot_full ;;
        "area") screenshot_area ;;
        "window") screenshot_window ;;
    esac
}

# Function to record screen
record_screen() {
    local file="$SCREENSHOT_DIR/recording_$TIMESTAMP.mp4"
    local pid_file="/tmp/wf-recorder.pid"
    
    if [[ -f "$pid_file" ]]; then
        # Stop recording
        local pid=$(cat "$pid_file")
        kill -INT "$pid" 2>/dev/null
        rm -f "$pid_file"
        notify-send "Recording Stopped" "Video saved as $(basename "$file")" \
            -t 3000 \
            -a "Screen Recorder"
    else
        # Start recording
        if command -v wf-recorder &> /dev/null; then
            notify-send "Recording Started" "Press Super+Shift+R to stop" \
                -t 3000 \
                -a "Screen Recorder"
            
            wf-recorder -f "$file" &
            echo $! > "$pid_file"
        else
            notify-send "Error" "wf-recorder not found. Please install wf-recorder." \
                -u critical \
                -t 5000
        fi
    fi
}

# Function to record area
record_area() {
    local file="$SCREENSHOT_DIR/recording_area_$TIMESTAMP.mp4"
    local pid_file="/tmp/wf-recorder-area.pid"
    
    if [[ -f "$pid_file" ]]; then
        # Stop recording
        local pid=$(cat "$pid_file")
        kill -INT "$pid" 2>/dev/null
        rm -f "$pid_file"
        notify-send "Area Recording Stopped" "Video saved as $(basename "$file")" \
            -t 3000 \
            -a "Screen Recorder"
    else
        # Start area recording
        if command -v wf-recorder &> /dev/null && command -v slurp &> /dev/null; then
            local area=$(slurp)
            if [[ -n "$area" ]]; then
                notify-send "Area Recording Started" "Press Super+Shift+Alt+R to stop" \
                    -t 3000 \
                    -a "Screen Recorder"
                
                wf-recorder -g "$area" -f "$file" &
                echo $! > "$pid_file"
            fi
        else
            notify-send "Error" "wf-recorder and slurp are required for area recording." \
                -u critical \
                -t 5000
        fi
    fi
}

# Main script logic
case "$1" in
    "--now"|"-n")
        screenshot_full
        ;;
    "--area"|"-a")
        screenshot_area
        ;;
    "--window"|"-w")
        screenshot_window
        ;;
    "--delay"|"-d")
        if [[ -n "$2" && "$2" =~ ^[0-9]+$ ]]; then
            screenshot_delay "$2" "${3:-full}"
        else
            echo "Usage: $0 --delay <seconds> [full|area|window]"
            exit 1
        fi
        ;;
    "--record"|"-r")
        record_screen
        ;;
    "--record-area"|"-ra")
        record_area
        ;;
    "--copy"|"-c")
        screenshot_area
        if [[ -f "$SCREENSHOT_DIR/screenshot_area_$TIMESTAMP.png" ]]; then
            copy_to_clipboard "$SCREENSHOT_DIR/screenshot_area_$TIMESTAMP.png"
        fi
        ;;
    "--help"|"-h"|*)
        echo "Enhanced Screenshot Script for Hyprland"
        echo ""
        echo "Usage: $0 [OPTION]"
        echo ""
        echo "Options:"
        echo "  --now, -n           Take full screen screenshot immediately"
        echo "  --area, -a          Take area screenshot with selection"
        echo "  --window, -w        Take active window screenshot"
        echo "  --delay, -d <sec>   Take screenshot after delay"
        echo "  --record, -r        Start/stop screen recording"
        echo "  --record-area, -ra  Start/stop area recording"
        echo "  --copy, -c          Take area screenshot and copy to clipboard"
        echo "  --help, -h          Show this help message"
        echo ""
        echo "Screenshots are saved to: $SCREENSHOT_DIR"
        ;;
esac