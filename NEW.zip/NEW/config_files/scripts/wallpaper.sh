#!/bin/bash

# Enhanced Wallpaper Management Script

WALLPAPER_DIR="$HOME/Pictures/Wallpapers"
CURRENT_WALLPAPER_FILE="$HOME/.config/.current_wallpaper"
SWWW_TRANSITION_TYPES=("simple" "fade" "left" "right" "top" "bottom" "wipe" "wave" "grow" "center" "any" "outer")

# Create wallpaper directory if it doesn't exist
mkdir -p "$WALLPAPER_DIR"

# Function to check if swww is running
check_swww() {
    if ! pgrep -x "swww-daemon" > /dev/null; then
        echo "Starting swww daemon..."
        swww init
        sleep 2
    fi
}

# Function to set wallpaper
set_wallpaper() {
    local wallpaper="$1"
    local transition="${2:-fade}"
    local duration="${3:-2}"
    
    if [[ ! -f "$wallpaper" ]]; then
        notify-send "Wallpaper Error" "File not found: $(basename "$wallpaper")" \
            -u critical \
            -t 3000 \
            -a "Wallpaper Manager"
        return 1
    fi
    
    check_swww
    
    # Set wallpaper with swww
    swww img "$wallpaper" \
        --transition-type "$transition" \
        --transition-duration "$duration" \
        --transition-fps 60 \
        --transition-bezier 0.25,0.1,0.25,1.0
    
    # Save current wallpaper
    echo "$wallpaper" > "$CURRENT_WALLPAPER_FILE"
    
    # Update colors for other applications
    update_colors "$wallpaper"
    
    notify-send "Wallpaper Changed" "Set to $(basename "$wallpaper")" \
        -i "$wallpaper" \
        -t 3000 \
        -a "Wallpaper Manager"
}

# Function to update colors based on wallpaper
update_colors() {
    local wallpaper="$1"
    
    # Generate color scheme with pywal if available
    if command -v wal &> /dev/null; then
        wal -i "$wallpaper" -n -q
        
        # Reload waybar with new colors
        if pgrep -x "waybar" > /dev/null; then
            pkill waybar
            sleep 1
            waybar &
        fi
        
        # Update kitty colors if running
        if command -v kitty &> /dev/null; then
            kitty @ set-colors --all --configured ~/.cache/wal/colors-kitty.conf 2>/dev/null || true
        fi
    fi
}

# Function to get random wallpaper
get_random_wallpaper() {
    local wallpapers=()
    
    # Find all image files in wallpaper directory
    while IFS= read -r -d '' file; do
        wallpapers+=("$file")
    done < <(find "$WALLPAPER_DIR" -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.webp" -o -iname "*.bmp" \) -print0 2>/dev/null)
    
    if [[ ${#wallpapers[@]} -eq 0 ]]; then
        notify-send "No Wallpapers Found" "Please add wallpapers to $WALLPAPER_DIR" \
            -u normal \
            -t 5000 \
            -a "Wallpaper Manager"
        return 1
    fi
    
    # Select random wallpaper
    local random_index=$((RANDOM % ${#wallpapers[@]}))
    echo "${wallpapers[$random_index]}"
}

# Function to show wallpaper menu
show_wallpaper_menu() {
    local wallpapers=()
    local display_names=()
    
    # Find all wallpapers
    while IFS= read -r -d '' file; do
        wallpapers+=("$file")
        display_names+=("$(basename "$file")")
    done < <(find "$WALLPAPER_DIR" -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.webp" -o -iname "*.bmp" \) -print0 2>/dev/null | sort -z)
    
    if [[ ${#wallpapers[@]} -eq 0 ]]; then
        notify-send "No Wallpapers Found" "Please add wallpapers to $WALLPAPER_DIR" \
            -u normal \
            -t 5000 \
            -a "Wallpaper Manager"
        return 1
    fi
    
    # Show rofi menu
    local selected=$(printf '%s\n' "${display_names[@]}" | rofi -dmenu -i -p "Select Wallpaper" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi)
    
    if [[ -n "$selected" ]]; then
        # Find the full path of selected wallpaper
        for i in "${!display_names[@]}"; do
            if [[ "${display_names[$i]}" == "$selected" ]]; then
                set_wallpaper "${wallpapers[$i]}"
                break
            fi
        done
    fi
}

# Function to start slideshow
start_slideshow() {
    local interval="${1:-300}" # Default 5 minutes
    local pid_file="/tmp/wallpaper_slideshow.pid"
    
    if [[ -f "$pid_file" ]]; then
        notify-send "Slideshow Already Running" "Stop current slideshow first" \
            -u normal \
            -t 3000 \
            -a "Wallpaper Manager"
        return 1
    fi
    
    # Start slideshow in background
    (
        echo $$ > "$pid_file"
        while [[ -f "$pid_file" ]]; do
            local wallpaper=$(get_random_wallpaper)
            if [[ -n "$wallpaper" ]]; then
                set_wallpaper "$wallpaper" "${SWWW_TRANSITION_TYPES[$((RANDOM % ${#SWWW_TRANSITION_TYPES[@]}))]}"
            fi
            sleep "$interval"
        done
    ) &
    
    notify-send "Slideshow Started" "Changing wallpaper every $((interval / 60)) minutes" \
        -t 3000 \
        -a "Wallpaper Manager"
}

# Function to stop slideshow
stop_slideshow() {
    local pid_file="/tmp/wallpaper_slideshow.pid"
    
    if [[ -f "$pid_file" ]]; then
        local pid=$(cat "$pid_file")
        kill "$pid" 2>/dev/null
        rm -f "$pid_file"
        notify-send "Slideshow Stopped" "Wallpaper slideshow has been stopped" \
            -t 3000 \
            -a "Wallpaper Manager"
    else
        notify-send "No Slideshow Running" "No slideshow to stop" \
            -u normal \
            -t 3000 \
            -a "Wallpaper Manager"
    fi
}

# Function to restore last wallpaper
restore_wallpaper() {
    if [[ -f "$CURRENT_WALLPAPER_FILE" ]]; then
        local last_wallpaper=$(cat "$CURRENT_WALLPAPER_FILE")
        if [[ -f "$last_wallpaper" ]]; then
            set_wallpaper "$last_wallpaper"
        else
            notify-send "Wallpaper Not Found" "Last wallpaper file no longer exists" \
                -u normal \
                -t 3000 \
                -a "Wallpaper Manager"
        fi
    else
        notify-send "No Previous Wallpaper" "No previous wallpaper to restore" \
            -u normal \
            -t 3000 \
            -a "Wallpaper Manager"
    fi
}

# Function to download wallpaper from URL
download_wallpaper() {
    local url="$1"
    local filename="wallpaper_$(date +%Y%m%d_%H%M%S).jpg"
    local filepath="$WALLPAPER_DIR/$filename"
    
    if command -v wget &> /dev/null; then
        wget -O "$filepath" "$url" && set_wallpaper "$filepath"
    elif command -v curl &> /dev/null; then
        curl -o "$filepath" "$url" && set_wallpaper "$filepath"
    else
        notify-send "Download Failed" "wget or curl required for downloading" \
            -u critical \
            -t 3000 \
            -a "Wallpaper Manager"
    fi
}

# Main script logic
case "$1" in
    "--random"|"-r")
        wallpaper=$(get_random_wallpaper)
        if [[ -n "$wallpaper" ]]; then
            set_wallpaper "$wallpaper"
        fi
        ;;
    "--menu"|"-m")
        show_wallpaper_menu
        ;;
    "--set"|"-s")
        if [[ -n "$2" ]]; then
            set_wallpaper "$2" "$3" "$4"
        else
            echo "Usage: $0 --set <wallpaper_path> [transition] [duration]"
            exit 1
        fi
        ;;
    "--slideshow"|"-sl")
        start_slideshow "$2"
        ;;
    "--stop-slideshow"|"-ss")
        stop_slideshow
        ;;
    "--restore"|"-rs")
        restore_wallpaper
        ;;
    "--download"|"-d")
        if [[ -n "$2" ]]; then
            download_wallpaper "$2"
        else
            echo "Usage: $0 --download <url>"
            exit 1
        fi
        ;;
    "--current"|"-c")
        if [[ -f "$CURRENT_WALLPAPER_FILE" ]]; then
            cat "$CURRENT_WALLPAPER_FILE"
        else
            echo "No current wallpaper set"
        fi
        ;;
    "--help"|"-h"|*)
        echo "Enhanced Wallpaper Management Script"
        echo ""
        echo "Usage: $0 [OPTION] [ARGUMENTS]"
        echo ""
        echo "Options:"
        echo "  --random, -r                Set random wallpaper"
        echo "  --menu, -m                  Show wallpaper selection menu"
        echo "  --set, -s <path> [trans] [dur]  Set specific wallpaper"
        echo "  --slideshow, -sl [interval] Start slideshow (default: 300s)"
        echo "  --stop-slideshow, -ss       Stop slideshow"
        echo "  --restore, -rs              Restore last wallpaper"
        echo "  --download, -d <url>        Download and set wallpaper from URL"
        echo "  --current, -c               Show current wallpaper path"
        echo "  --help, -h                  Show this help message"
        echo ""
        echo "Wallpaper directory: $WALLPAPER_DIR"
        echo "Supported formats: jpg, jpeg, png, webp, bmp"
        ;;
esac