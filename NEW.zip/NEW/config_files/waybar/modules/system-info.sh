#!/bin/bash

# System Information Module for Waybar

# Function to get CPU usage
get_cpu_usage() {
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//')
    echo "${cpu_usage%.*}"
}

# Function to get memory usage
get_memory_usage() {
    local mem_info=$(free | grep Mem)
    local total=$(echo $mem_info | awk '{print $2}')
    local used=$(echo $mem_info | awk '{print $3}')
    local percentage=$((used * 100 / total))
    echo "$percentage"
}

# Function to get disk usage
get_disk_usage() {
    local disk_usage=$(df -h / | awk 'NR==2{print $5}' | sed 's/%//')
    echo "$disk_usage"
}

# Function to get temperature
get_temperature() {
    local temp=""
    
    # Try different temperature sources
    if [[ -f /sys/class/thermal/thermal_zone0/temp ]]; then
        temp=$(cat /sys/class/thermal/thermal_zone0/temp)
        temp=$((temp / 1000))
    elif command -v sensors &> /dev/null; then
        temp=$(sensors | grep -E "Core 0|Tctl|CPU" | head -1 | grep -oE '[0-9]+\.[0-9]+°C' | head -1 | sed 's/°C//')
        temp=${temp%.*}
    elif [[ -f /sys/devices/platform/coretemp.0/hwmon/hwmon*/temp1_input ]]; then
        temp=$(cat /sys/devices/platform/coretemp.0/hwmon/hwmon*/temp1_input 2>/dev/null | head -1)
        temp=$((temp / 1000))
    fi
    
    echo "${temp:-N/A}"
}

# Function to get load average
get_load_average() {
    local load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    echo "$load"
}

# Function to get uptime
get_uptime() {
    local uptime_seconds=$(cat /proc/uptime | awk '{print int($1)}')
    local days=$((uptime_seconds / 86400))
    local hours=$(((uptime_seconds % 86400) / 3600))
    local minutes=$(((uptime_seconds % 3600) / 60))
    
    if [[ $days -gt 0 ]]; then
        echo "${days}d ${hours}h"
    elif [[ $hours -gt 0 ]]; then
        echo "${hours}h ${minutes}m"
    else
        echo "${minutes}m"
    fi
}

# Function to get network usage
get_network_usage() {
    local interface=""
    local rx_bytes=0
    local tx_bytes=0
    
    # Find active network interface
    interface=$(ip route | grep default | awk '{print $5}' | head -1)
    
    if [[ -n "$interface" && -f "/sys/class/net/$interface/statistics/rx_bytes" ]]; then
        rx_bytes=$(cat "/sys/class/net/$interface/statistics/rx_bytes")
        tx_bytes=$(cat "/sys/class/net/$interface/statistics/tx_bytes")
        
        # Convert to human readable format
        rx_mb=$((rx_bytes / 1024 / 1024))
        tx_mb=$((tx_bytes / 1024 / 1024))
        
        echo "↓${rx_mb}MB ↑${tx_mb}MB"
    else
        echo "N/A"
    fi
}

# Function to get GPU usage (NVIDIA)
get_gpu_usage() {
    if command -v nvidia-smi &> /dev/null; then
        local gpu_usage=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits)
        echo "${gpu_usage}%"
    else
        echo "N/A"
    fi
}

# Function to get GPU temperature (NVIDIA)
get_gpu_temp() {
    if command -v nvidia-smi &> /dev/null; then
        local gpu_temp=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits)
        echo "${gpu_temp}°C"
    else
        echo "N/A"
    fi
}

# Function to format output for Waybar
format_output() {
    local cpu=$(get_cpu_usage)
    local memory=$(get_memory_usage)
    local disk=$(get_disk_usage)
    local temp=$(get_temperature)
    local load=$(get_load_average)
    local uptime=$(get_uptime)
    local network=$(get_network_usage)
    
    # Create tooltip with detailed information
    local tooltip="System Information\n"
    tooltip+="CPU Usage: ${cpu}%\n"
    tooltip+="Memory Usage: ${memory}%\n"
    tooltip+="Disk Usage: ${disk}%\n"
    tooltip+="Temperature: ${temp}°C\n"
    tooltip+="Load Average: ${load}\n"
    tooltip+="Uptime: ${uptime}\n"
    tooltip+="Network: ${network}"
    
    # Add GPU info if available
    local gpu_usage=$(get_gpu_usage)
    local gpu_temp=$(get_gpu_temp)
    if [[ "$gpu_usage" != "N/A" ]]; then
        tooltip+="\nGPU Usage: ${gpu_usage}\n"
        tooltip+="GPU Temperature: ${gpu_temp}"
    fi
    
    # Determine status class based on usage
    local class="normal"
    if [[ $cpu -gt 80 || $memory -gt 80 || $disk -gt 90 ]]; then
        class="critical"
    elif [[ $cpu -gt 60 || $memory -gt 60 || $disk -gt 80 ]]; then
        class="warning"
    fi
    
    # Create main display text
    local text="💻 ${cpu}% 🧠 ${memory}% 💾 ${disk}%"
    
    # Add temperature if available
    if [[ "$temp" != "N/A" ]]; then
        if [[ $temp -gt 80 ]]; then
            text+=" 🔥 ${temp}°C"
        elif [[ $temp -gt 60 ]]; then
            text+=" 🌡️ ${temp}°C"
        else
            text+=" ❄️ ${temp}°C"
        fi
    fi
    
    # Output JSON for Waybar
    echo "{\"text\":\"$text\",\"tooltip\":\"$tooltip\",\"class\":\"$class\"}"
}

# Function to get detailed system info for rofi menu
show_detailed_info() {
    local cpu=$(get_cpu_usage)
    local memory=$(get_memory_usage)
    local disk=$(get_disk_usage)
    local temp=$(get_temperature)
    local load=$(get_load_average)
    local uptime=$(get_uptime)
    local network=$(get_network_usage)
    local gpu_usage=$(get_gpu_usage)
    local gpu_temp=$(get_gpu_temp)
    
    local info="🖥️  System Information\n\n"
    info+="💻 CPU Usage: ${cpu}%\n"
    info+="🧠 Memory Usage: ${memory}%\n"
    info+="💾 Disk Usage: ${disk}%\n"
    info+="🌡️  Temperature: ${temp}°C\n"
    info+="⚖️  Load Average: ${load}\n"
    info+="⏰ Uptime: ${uptime}\n"
    info+="🌐 Network: ${network}\n"
    
    if [[ "$gpu_usage" != "N/A" ]]; then
        info+="🎮 GPU Usage: ${gpu_usage}\n"
        info+="🔥 GPU Temperature: ${gpu_temp}\n"
    fi
    
    # Additional system information
    info+="\n📊 Additional Info:\n"
    info+="🐧 Kernel: $(uname -r)\n"
    info+="💽 Architecture: $(uname -m)\n"
    info+="🏠 Hostname: $(hostname)\n"
    info+="👤 User: $(whoami)\n"
    info+="🖼️  Desktop: ${XDG_CURRENT_DESKTOP:-Unknown}\n"
    info+="🪟 Session: ${XDG_SESSION_TYPE:-Unknown}\n"
    
    echo -e "$info"
}

# Function to show process information
show_process_info() {
    echo "🔄 Top Processes by CPU Usage:"
    ps aux --sort=-%cpu | head -11 | awk 'NR==1{print $0} NR>1{printf "%-8s %-6s %-6s %s\n", $1, $2, $3, $11}'
    echo
    echo "🧠 Top Processes by Memory Usage:"
    ps aux --sort=-%mem | head -11 | awk 'NR==1{print $0} NR>1{printf "%-8s %-6s %-6s %s\n", $1, $2, $4, $11}'
}

# Function to show disk information
show_disk_info() {
    echo "💾 Disk Usage Information:"
    df -h | grep -E "^/dev|^tmpfs" | awk '{printf "%-20s %-8s %-8s %-8s %-6s %s\n", $1, $2, $3, $4, $5, $6}'
    echo
    echo "📁 Directory Sizes (Top 10):"
    du -sh /* 2>/dev/null | sort -hr | head -10
}

# Function to show network information
show_network_info() {
    echo "🌐 Network Information:"
    echo
    echo "📡 Active Interfaces:"
    ip -4 addr show | grep -E "^[0-9]+:|inet " | sed 's/^[0-9]*: //' | sed 's/inet /  IP: /'
    echo
    echo "🔗 Routing Table:"
    ip route | head -10
    echo
    echo "📊 Network Statistics:"
    cat /proc/net/dev | head -3
    cat /proc/net/dev | grep -E "(eth|wlan|enp|wlp)" | head -5
}

# Main execution based on argument
case "${1:-format}" in
    "format")
        format_output
        ;;
    "detailed")
        show_detailed_info
        ;;
    "processes")
        show_process_info
        ;;
    "disk")
        show_disk_info
        ;;
    "network")
        show_network_info
        ;;
    "menu")
        # Show interactive menu with rofi
        choice=$(echo -e "📊 System Overview\n🔄 Process Information\n💾 Disk Information\n🌐 Network Information\n❌ Close" | rofi -dmenu -i -p "System Info" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi)
        
        case "$choice" in
            "📊 System Overview")
                show_detailed_info | rofi -dmenu -i -p "System Information" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi
                ;;
            "🔄 Process Information")
                show_process_info | rofi -dmenu -i -p "Process Information" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi
                ;;
            "💾 Disk Information")
                show_disk_info | rofi -dmenu -i -p "Disk Information" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi
                ;;
            "🌐 Network Information")
                show_network_info | rofi -dmenu -i -p "Network Information" -theme ~/.config/rofi/themes/catppuccin-mocha.rasi
                ;;
        esac
        ;;
    *)
        echo "Usage: $0 [format|detailed|processes|disk|network|menu]"
        exit 1
        ;;
esac
