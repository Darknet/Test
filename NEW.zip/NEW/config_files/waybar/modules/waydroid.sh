#!/bin/bash

# Waydroid Status Module for Waybar

get_waydroid_status() {
    if ! command -v waydroid &> /dev/null; then
        echo ""
        return
    fi
    
    # Check if Waydroid session is running
    if pgrep -f "waydroid" > /dev/null; then
        # Check if container is running
        if waydroid status | grep -q "Session:\s*RUNNING"; then
            echo "ON"
        else
            echo "STARTING"
        fi
    else
        echo "OFF"
    fi
}

status=$(get_waydroid_status)
echo "$status"