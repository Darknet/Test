#!/bin/bash

# VPN Status Module for Waybar

get_vpn_status() {
    local vpn_connections=""
    local active_vpns=""
    
    # Check for active VPN connections via NetworkManager
    if command -v nmcli &> /dev/null; then
        active_vpns=$(nmcli connection show --active | grep -E "(vpn|wireguard|openvpn)" | wc -l)
        vpn_connections=$(nmcli connection show --active | grep -E "(vpn|wireguard|openvpn)" | awk '{print $1}' | head -1)
    fi
    
    # Check for WireGuard interfaces
    local wg_interfaces=""
    if command -v wg &> /dev/null; then
        wg_interfaces=$(wg show interfaces 2>/dev/null | wc -l)
    fi
    
    # Check for OpenVPN processes
    local openvpn_processes=""
    openvpn_processes=$(pgrep -c openvpn 2>/dev/null || echo "0")
    
    local total_vpns=$((active_vpns + wg_interfaces + openvpn_processes))
    
    if [[ $total_vpns -gt 0 ]]; then
        local status="connected"
        local tooltip="VPN Connected"
        local text="🔒"
        local class="connected"
        
        if [[ -n "$vpn_connections" ]]; then
            tooltip="VPN: $vpn_connections"
        elif [[ $wg_interfaces -gt 0 ]]; then
            tooltip="WireGuard Active"
        elif [[ $openvpn_processes -gt 0 ]]; then
            tooltip="OpenVPN Active"
        fi
        
        if [[ $total_vpns -gt 1 ]]; then
            text="🔒 $total_vpns"
            tooltip="$tooltip (+$((total_vpns - 1)) more)"
        fi
    else
        local status="disconnected"
        local tooltip="VPN Disconnected"
        local text="🔓"
        local class="disconnected"
    fi
    
    # Output JSON for Waybar
    echo "{\"text\":\"$text\",\"tooltip\":\"$tooltip\",\"class\":\"$class\",\"alt\":\"$status\"}"
}

get_vpn_status