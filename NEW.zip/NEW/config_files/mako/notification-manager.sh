#!/bin/bash

# Advanced Notification Manager for Mako

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configuration
MAKO_CONFIG="$HOME/.config/mako/config"
HISTORY_FILE="$HOME/.local/share/mako/history.json"
DND_FILE="$HOME/.local/share/mako/dnd"
THEMES_DIR="$HOME/.config/mako/themes"

# Function to print colored output
print_color() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Function to check if mako is running
is_mako_running() {
    pgrep -x mako > /dev/null
}

# Function to start mako
start_mako() {
    if ! is_mako_running; then
        print_color $BLUE "🚀 Starting Mako notification daemon..."
        mako &
        sleep 2
        if is_mako_running; then
            print_color $GREEN "✅ Mako started successfully"
        else
            print_color $RED "❌ Failed to start Mako"
            return 1
        fi
    else
        print_color $YELLOW "⚠️  Mako is already running"
    fi
}

# Function to stop mako
stop_mako() {
    if is_mako_running; then
        print_color $BLUE "🛑 Stopping Mako notification daemon..."
        killall mako
        sleep 1
        if ! is_mako_running; then
            print_color $GREEN "✅ Mako stopped successfully"
        else
            print_color $RED "❌ Failed to stop Mako"
            return 1
        fi
    else
        print_color $YELLOW "⚠️  Mako is not running"
    fi
}

# Function to restart mako
restart_mako() {
    print_color $BLUE "🔄 Restarting Mako..."
    stop_mako
    sleep 1
    start_mako
}

# Function to reload mako configuration
reload_config() {
    if is_mako_running; then
        print_color $BLUE "🔄 Reloading Mako configuration..."
        makoctl reload
        print_color $GREEN "✅ Configuration reloaded"
    else
        print_color $RED "❌ Mako is not running"
        return 1
    fi
}

# Function to show mako status
show_status() {
    print_color $CYAN "📊 Mako Status Information"
    echo "=========================="
    
    if is_mako_running; then
        print_color $GREEN "Status: Running ✅"
        local pid=$(pgrep -x mako)
        print_color $BLUE "PID: $pid"
        
        # Show memory usage
        local mem_usage=$(ps -p $pid -o rss= 2>/dev/null)
        if [[ -n "$mem_usage" ]]; then
            mem_usage=$((mem_usage / 1024))
            print_color $BLUE "Memory Usage: ${mem_usage}MB"
        fi
        
        # Show uptime
        local start_time=$(ps -p $pid -o lstart= 2>/dev/null)
        if [[ -n "$start_time" ]]; then
            print_color $BLUE "Started: $start_time"
        fi
    else
        print_color $RED "Status: Not Running ❌"
    fi
    
    # Check DND status
    if [[ -f "$DND_FILE" ]]; then
        print_color $YELLOW "Do Not Disturb: ON 🔕"
    else
        print_color $GREEN "Do Not Disturb: OFF 🔔"
    fi
    
    # Show configuration file
    if [[ -f "$MAKO_CONFIG" ]]; then
        print_color $GREEN "Config File: Found ✅"
        print_color $BLUE "Location: $MAKO_CONFIG"
    else
        print_color $RED "Config File: Not Found ❌"
    fi
    
    # Show notification count
    local notification_count=$(makoctl list 2>/dev/null | jq length 2>/dev/null || echo "0")
    print_color $BLUE "Active Notifications: $notification_count"
    
    echo
}

# Function to send test notifications
send_test_notifications() {
    print_color $BLUE "🧪 Sending test notifications..."
    
    if ! is_mako_running; then
        print_color $RED "❌ Mako is not running. Starting it first..."
        start_mako
    fi
    
    # Test different urgency levels
    notify-send "Test - Normal" "This is a normal priority notification" --urgency=normal --icon=dialog-information
    sleep 1
    
    notify-send "Test - Low Priority" "This is a low priority notification" --urgency=low --icon=dialog-information
    sleep 1
    
    notify-send "Test - Critical" "This is a critical priority notification" --urgency=critical --icon=dialog-warning
    sleep 1
    
    # Test with different categories
    notify-send "Test - Email" "You have new email" --category=email --icon=mail-unread
    sleep 1
    
    notify-send "Test - Music" "Now playing: Test Song" --category=music --icon=audio-headphones
    sleep 1
    
    # Test long notification
    notify-send "Test - Long Text" "This is a longer notification to test text wrapping and how the notification daemon handles multiple lines of text content. It should wrap properly and display all the information clearly." --icon=dialog-information
    sleep 1
    
    # Test with actions (if supported)
    notify-send "Test - With Actions" "This notification has actions" --action="reply,Reply" --action="dismiss,Dismiss" --icon=dialog-question
    
    print_color $GREEN "✅ Test notifications sent"
}

# Function to manage notification history
manage_history() {
    local action=${1:-show}
    
    case "$action" in
        "show")
            if [[ -f "$HISTORY_FILE" ]]; then
                print_color $CYAN "📚 Notification History"
                echo "======================="
                jq -r '.[] | "[\(.timestamp | strftime("%Y-%m-%d %H:%M:%S"))] \(.app_name): \(.summary)"' "$HISTORY_FILE" 2>/dev/null | tail -20
            else
                print_color $YELLOW "No notification history found"
            fi
            ;;
        "clear")
            if [[ -f "$HISTORY_FILE" ]]; then
                rm "$HISTORY_FILE"
                print_color $GREEN "✅ Notification history cleared"
            else
                print_color $YELLOW "No history to clear"
            fi
            ;;
        "export")
            if [[ -f "$HISTORY_FILE" ]]; then
                local export_file="$HOME/notification_history_$(date +%Y%m%d_%H%M%S).json"
                cp "$HISTORY_FILE" "$export_file"
                print_color $GREEN "✅ History exported to: $export_file"
            else
                print_color $YELLOW "No history to export"
            fi
            ;;
        *)
            print_color $RED "Invalid history action. Use: show, clear, or export"
            return 1
            ;;
    esac
}

# Function to toggle Do Not Disturb
toggle_dnd() {
    if [[ -f "$DND_FILE" ]]; then
        rm "$DND_FILE"
        if is_mako_running; then
            makoctl mode -r dnd 2>/dev/null
        fi
        print_color $GREEN "🔔 Do Not Disturb: OFF"
        notify-send "Do Not Disturb" "Notifications enabled" --icon=notification-symbolic --urgency=low
    else
        touch "$DND_FILE"
        if is_mako_running; then
            makoctl mode -a dnd 2>/dev/null
        fi
        print_color $YELLOW "🔕 Do Not Disturb: ON"
        notify-send "Do Not Disturb" "Notifications disabled" --icon=notification-symbolic --urgency=low
    fi
}

# Function to dismiss notifications
dismiss_notifications() {
    local action=${1:-all}
    
    if ! is_mako_running; then
        print_color $RED "❌ Mako is not running"
        return 1
    fi
    
    case "$action" in
        "all")
            makoctl dismiss --all
            print_color $GREEN "✅ All notifications dismissed"
            ;;
        "oldest")
            makoctl dismiss --oldest
            print_color $GREEN "✅ Oldest notification dismissed"
            ;;
        "group")
            local group=${2:-""}
            if [[ -n "$group" ]]; then
                makoctl dismiss --group="$group"
                print_color $GREEN "✅ Notifications from group '$group' dismissed"
            else
                print_color $RED "❌ Group name required"
                return 1
            fi
            ;;
        *)
            print_color $RED "Invalid dismiss action. Use: all, oldest, or group <name>"
            return 1
            ;;
    esac
}

# Function to list active notifications
list_notifications() {
    if ! is_mako_running; then
        print_color $RED "❌ Mako is not running"
        return 1
    fi
    
    print_color $CYAN "📋 Active Notifications"
    echo "======================"
    
    local notifications=$(makoctl list 2>/dev/null)
    if [[ -n "$notifications" ]]; then
        echo "$notifications" | jq -r '.data[] | "ID: \(.id.data) | App: \(.app_name.data) | Summary: \(.summary.data)"' 2>/dev/null || echo "Failed to parse notifications"
    else
        print_color $YELLOW "No active notifications"
    fi
}

# Function to change notification theme
change_theme() {
    local theme=${1:-""}
    
    if [[ -z "$theme" ]]; then
        print_color $CYAN "Available themes:"
        if [[ -d "$THEMES_DIR" ]]; then
            ls "$THEMES_DIR"/*.conf 2>/dev/null | xargs -n1 basename | sed 's/.conf$//' | sed 's/^/  - /'
        fi
        return 0
    fi
    
    local theme_file="$THEMES_DIR/$theme.conf"
    if [[ -f "$theme_file" ]]; then
        cp "$theme_file" "$MAKO_CONFIG"
        print_color $GREEN "✅ Theme '$theme' applied"
        reload_config
    else
        print_color $RED "❌ Theme '$theme' not found"
        return 1
    fi
}

# Function to show configuration
show_config() {
    if [[ -f "$MAKO_CONFIG" ]]; then
        print_color $CYAN "📄 Current Mako Configuration"
        echo "============================="
        cat "$MAKO_CONFIG"
    else
        print_color $RED "❌ Configuration file not found"
        return 1
    fi
}

# Function to edit configuration
edit_config() {
    local editor=${EDITOR:-nano}
    
    if [[ -f "$MAKO_CONFIG" ]]; then
        $editor "$MAKO_CONFIG"
        print_color $GREEN "✅ Configuration edited"
        
        read -p "Reload configuration? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            reload_config
        fi
    else
        print_color $RED "❌ Configuration file not found"
        return 1
    fi
}

# Function to show help
show_help() {
    print_color $CYAN "🔧 Mako Notification Manager"
    echo "============================"
    echo
    print_color $YELLOW "Usage: $0 [COMMAND] [OPTIONS]"
    echo
    print_color $GREEN "Commands:"
    echo "  start           Start Mako daemon"
    echo "  stop            Stop Mako daemon"
    echo "  restart         Restart Mako daemon"
    echo "  reload          Reload configuration"
    echo "  status          Show Mako status"
    echo "  test            Send test notifications"
    echo "  dnd             Toggle Do Not Disturb"
    echo "  dismiss [all|oldest|group <name>]  Dismiss notifications"
    echo "  list            List active notifications"
    echo "  history [show|clear|export]        Manage notification history"
    echo "  theme [name]    Change notification theme"
    echo "  config          Show current configuration"
    echo "  edit            Edit configuration file"
    echo "  help            Show this help message"
    echo
    print_color $GREEN "Examples:"
    echo "  $0 start                    # Start Mako"
    echo "  $0 test                     # Send test notifications"
    echo "  $0 dismiss group firefox    # Dismiss Firefox notifications"
    echo "  $0 theme dark              # Apply dark theme"
    echo "  $0 history clear           # Clear notification history"
    echo
}

# Main function
main() {
    local command=${1:-help}
    
    case "$command" in
        "start")
            start_mako
            ;;
        "stop")
            stop_mako
            ;;
        "restart")
            restart_mako
            ;;
        "reload")
            reload_config
            ;;
        "status")
            show_status
            ;;
        "test")
            send_test_notifications
            ;;
        "dnd")
            toggle_dnd
            ;;
        "dismiss")
            dismiss_notifications "${2:-all}" "$3"
            ;;
        "list")
            list_notifications
            ;;
        "history")
            manage_history "${2:-show}"
            ;;
        "theme")
            change_theme "$2"
            ;;
        "config")
            show_config
            ;;
        "edit")
            edit_config
            ;;
        "help"|"--help"|"-h")
            show_help
            ;;
        *)
            print_color $RED "❌ Unknown command: $command"
            echo
            show_help
            exit 1
            ;;
    esac
}

# Run main function if script is executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
