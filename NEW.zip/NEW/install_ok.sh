#!/bin/bash

# Hyprland Dotfiles Installation Script
# Complete installation with all configurations and dependencies

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_DIR="$HOME/.config"
LOCAL_BIN="$HOME/.local/bin"
LOCAL_SHARE="$HOME/.local/share"
FONTS_DIR="$LOCAL_SHARE/fonts"
THEMES_DIR="$LOCAL_SHARE/themes"
ICONS_DIR="$LOCAL_SHARE/icons"

# Function to print colored output
print_color() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Function to print headers
print_header() {
    echo
    print_color $PURPLE "================================"
    print_color $PURPLE "$1"
    print_color $PURPLE "================================"
    echo
}

# Function to print step
print_step() {
    print_color $CYAN "➤ $1"
}

# Function to print success
print_success() {
    print_color $GREEN "✅ $1"
}

# Function to print warning
print_warning() {
    print_color $YELLOW "⚠️  $1"
}

# Function to print error
print_error() {
    print_color $RED "❌ $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check system compatibility
check_system() {
    print_header "System Compatibility Check"
    
    # Check if running on Linux
    if [[ "$OSTYPE" != "linux-gnu"* ]]; then
        print_error "This script is designed for Linux systems only"
        exit 1
    fi
    
    # Check if Wayland is available
    if [[ -z "$WAYLAND_DISPLAY" && -z "$XDG_SESSION_TYPE" ]]; then
        print_warning "Wayland session not detected. Some features may not work properly."
    fi
    
    # Detect distribution
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        print_success "Detected system: $PRETTY_NAME"
    else
        print_warning "Could not detect Linux distribution"
    fi
    
    # Check architecture
    local arch=$(uname -m)
    print_success "Architecture: $arch"
    
    if [[ "$arch" != "x86_64" && "$arch" != "aarch64" ]]; then
        print_warning "Untested architecture: $arch"
    fi
}

# Function to check dependencies
check_dependencies() {
    print_header "Checking Dependencies"
    
    local required_deps=(
        "git"
        "curl"
        "unzip"
        "fc-cache"
    )
    
    local optional_deps=(
        "hyprland"
        "waybar"
        "mako"
        "rofi"
        "alacritty"
        "jq"
        "sensors"
        "xclip"
        "wl-clipboard"
        "grim"
        "slurp"
        "swappy"
        "playerctl"
        "pavucontrol"
        "brightnessctl"
        "networkmanager"
    )
    
    local missing_required=()
    local missing_optional=()
    
    # Check required dependencies
    print_step "Checking required dependencies..."
    for dep in "${required_deps[@]}"; do
        if command_exists "$dep"; then
            print_success "$dep is installed"
        else
            missing_required+=("$dep")
            print_error "$dep is missing (required)"
        fi
    done
    
    # Check optional dependencies
    print_step "Checking optional dependencies..."
    for dep in "${optional_deps[@]}"; do
        if command_exists "$dep"; then
            print_success "$dep is installed"
        else
            missing_optional+=("$dep")
            print_warning "$dep is missing (optional)"
        fi
    done
    
    # Handle missing required dependencies
    if [[ ${#missing_required[@]} -gt 0 ]]; then
        print_error "Missing required dependencies: ${missing_required[*]}"
        print_color $BLUE "Please install them using your package manager:"
        
        if command_exists "pacman"; then
            print_color $CYAN "  sudo pacman -S ${missing_required[*]}"
        elif command_exists "apt"; then
            print_color $CYAN "  sudo apt install ${missing_required[*]}"
        elif command_exists "dnf"; then
            print_color $CYAN "  sudo dnf install ${missing_required[*]}"
        elif command_exists "zypper"; then
            print_color $CYAN "  sudo zypper install ${missing_required[*]}"
        else
            print_color $CYAN "  Install using your package manager: ${missing_required[*]}"
        fi
        
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
    
    # Show optional dependencies installation
    if [[ ${#missing_optional[@]} -gt 0 ]]; then
        print_warning "Missing optional dependencies for full functionality:"
        for dep in "${missing_optional[@]}"; do
            print_color $YELLOW "  - $dep"
        done
        echo
        print_color $BLUE "Install them for full functionality:"
        
        if command_exists "pacman"; then
            print_color $CYAN "  sudo pacman -S ${missing_optional[*]}"
        elif command_exists "apt"; then
            print_color $CYAN "  sudo apt install ${missing_optional[*]}"
        elif command_exists "dnf"; then
            print_color $CYAN "  sudo dnf install ${missing_optional[*]}"
        elif command_exists "zypper"; then
            print_color $CYAN "  sudo zypper install ${missing_optional[*]}"
        fi
        echo
    fi
}

# Function to create necessary directories
create_directories() {
    print_header "Creating Directory Structure"
    
    local directories=(
        "$CONFIG_DIR"
        "$CONFIG_DIR/hypr"
        "$CONFIG_DIR/waybar"
        "$CONFIG_DIR/waybar/modules"
        "$CONFIG_DIR/mako"
        "$CONFIG_DIR/mako/themes"
        "$CONFIG_DIR/mako/apps"
        "$CONFIG_DIR/rofi"
        "$CONFIG_DIR/rofi/themes"
        "$CONFIG_DIR/alacritty"
        "$CONFIG_DIR/scripts"
        "$CONFIG_DIR/systemd/user"
        "$LOCAL_BIN"
        "$LOCAL_SHARE"
        "$FONTS_DIR"
        "$THEMES_DIR"
        "$ICONS_DIR"
        "$LOCAL_SHARE/mako"
        "$LOCAL_SHARE/applications"
        "$HOME/.cache/rofi"
        "$HOME/.cache/waybar"
    )
    
    for dir in "${directories[@]}"; do
        if [[ ! -d "$dir" ]]; then
            print_step "Creating directory: $dir"
            mkdir -p "$dir"
            print_success "Created $dir"
        else
            print_success "Directory exists: $dir"
        fi
    done
}

# Function to backup existing configurations
create_backup() {
    print_header "Creating Configuration Backup"
    
    local backup_dir="$HOME/.config/dotfiles-backup-$(date +%Y%m%d_%H%M%S)"
    local configs_to_backup=(
        "hypr"
        "waybar"
        "mako"
        "rofi"
        "alacritty"
        "scripts"
    )
    
    local backup_created=false
    
    for config in "${configs_to_backup[@]}"; do
        if [[ -d "$CONFIG_DIR/$config" ]]; then
            if [[ "$backup_created" == false ]]; then
                print_step "Creating backup directory: $backup_dir"
                mkdir -p "$backup_dir"
                backup_created=true
            fi
            
            print_step "Backing up $config configuration..."
            cp -r "$CONFIG_DIR/$config" "$backup_dir/"
            print_success "$config backed up"
        fi
    done
    
    if [[ "$backup_created" == true ]]; then
        # Create restore script
        cat > "$backup_dir/restore.sh" << EOFrestore
#!/bin/bash
# Restore script for dotfiles backup
# Created: $(date)

echo "🔄 Restoring dotfiles backup..."

BACKUP_DIR="\$(dirname "\$0")"
CONFIG_DIR="\$HOME/.config"

for item in "\$BACKUP_DIR"/*; do
    if [[ -d "\$item" ]]; then
        config_name="\$(basename "\$item")"
        if [[ "\$config_name" != "restore.sh" ]]; then
            echo "Restoring \$config_name..."
            rm -rf "\$CONFIG_DIR/\$config_name"
            cp -r "\$item" "\$CONFIG_DIR/"
        fi
    fi
done

echo "✅ Backup restored successfully"
echo "💡 You may need to restart your session for changes to take effect"
EOFrestore
        
        chmod +x "$backup_dir/restore.sh"
        print_success "Backup created at: $backup_dir"
        print_color $BLUE "💡 Use '$backup_dir/restore.sh' to restore if needed"
    else
        print_success "No existing configurations found to backup"
    fi
}

# Function to copy configuration files
copy_configs() {
    print_header "Copying Configuration Files"
    
    # Copy Hyprland configuration
    if [[ -d "$SCRIPT_DIR/config/hypr" ]]; then
        print_step "Copying Hyprland configuration..."
        cp -r "$SCRIPT_DIR/config/hypr/"* "$CONFIG_DIR/hypr/"
        print_success "Hyprland configuration copied"
    fi
    
    # Copy Waybar configuration
    if [[ -d "$SCRIPT_DIR/config/waybar" ]]; then
        print_step "Copying Waybar configuration..."
        cp -r "$SCRIPT_DIR/config/waybar/"* "$CONFIG_DIR/waybar/"
        print_success "Waybar configuration copied"
    fi
    
    # Copy Mako configuration
    if [[ -d "$SCRIPT_DIR/config/mako" ]]; then
        print_step "Copying Mako configuration..."
        cp -r "$SCRIPT_DIR/config/mako/"* "$CONFIG_DIR/mako/"
        print_success "Mako configuration copied"
    fi
    
    # Copy Rofi configuration
    if [[ -d "$SCRIPT_DIR/config/rofi" ]]; then
        print_step "Copying Rofi configuration..."
        cp -r "$SCRIPT_DIR/config/rofi/"* "$CONFIG_DIR/rofi/"
        print_success "Rofi configuration copied"
    fi
    
    # Copy Alacritty configuration
    if [[ -d "$SCRIPT_DIR/config/alacritty" ]]; then
        print_step "Copying Alacritty configuration..."
        cp -r "$SCRIPT_DIR/config/alacritty/"* "$CONFIG_DIR/alacritty/"
        print_success "Alacritty configuration copied"
    fi
    
    # Copy scripts
    if [[ -d "$SCRIPT_DIR/config/scripts" ]]; then
        print_step "Copying custom scripts..."
        cp -r "$SCRIPT_DIR/config/scripts/"* "$CONFIG_DIR/scripts/"
        print_success "Scripts copied"
    fi
}

# Function to set proper permissions
set_permissions() {
    print_header "Setting File Permissions"
    
    # Make scripts executable
    if [[ -d "$CONFIG_DIR/scripts" ]]; then
        print_step "Setting executable permissions for scripts..."
        find "$CONFIG_DIR/scripts" -type f -name "*.sh" -exec chmod +x {} \;
        print_success "Script permissions set"
    fi
    
    # Make Waybar modules executable
    if [[ -d "$CONFIG_DIR/waybar/modules" ]]; then
        print_step "Setting executable permissions for Waybar modules..."
        find "$CONFIG_DIR/waybar/modules" -type f -name "*.sh" -exec chmod +x {} \;
        print_success "Waybar module permissions set"
    fi
    
    # Ensure config files have proper permissions
    find "$CONFIG_DIR" -type f -name "*.conf" -exec chmod 644 {} \; 2>/dev/null || true
    find "$CONFIG_DIR" -type f -name "*.css" -exec chmod 644 {} \; 2>/dev/null || true
    find "$CONFIG_DIR" -type f -name "*.toml" -exec chmod 644 {} \; 2>/dev/null || true
    find "$CONFIG_DIR" -type f -name "*.rasi" -exec chmod 644 {} \; 2>/dev/null || true
    
    print_success "File permissions configured"
}

# Function to install fonts
install_fonts() {
    print_header "Installing Fonts"
    
    if [[ -d "$SCRIPT_DIR/fonts" ]]; then
        print_step "Installing custom fonts..."
        cp -r "$SCRIPT_DIR/fonts/"* "$FONTS_DIR/"
        print_success "Custom fonts installed"
    fi
    
    # Download and install JetBrains Mono Nerd Font if not present
    if ! fc-list | grep -i "jetbrainsmono nerd font" > /dev/null; then
        print_step "Downloading JetBrains Mono Nerd Font..."
        
        local font_url="https://github.com/ryanoasis/nerd-fonts/releases/download/v3.1.1/JetBrainsMono.zip"
        local temp_dir=$(mktemp -d)
        
        if curl -L "$font_url" -o "$temp_dir/JetBrainsMono.zip"; then
            print_step "Extracting JetBrains Mono Nerd Font..."
            unzip -q "$temp_dir/JetBrainsMono.zip" -d "$temp_dir/jetbrains"
            cp "$temp_dir/jetbrains/"*.ttf "$FONTS_DIR/" 2>/dev/null || true
            rm -rf "$temp_dir"
            print_success "JetBrains Mono Nerd Font installed"
        else
            print_warning "Failed to download JetBrains Mono Nerd Font"
        fi
    else
        print_success "JetBrains Mono Nerd Font already installed"
    fi
    
    # Refresh font cache
    print_step "Refreshing font cache..."
    fc-cache -fv > /dev/null 2>&1
    print_success "Font cache refreshed"
}

# Function to setup themes
setup_themes() {
    print_header "Setting Up Themes"
    
    # Copy theme files if they exist
    if [[ -d "$SCRIPT_DIR/themes" ]]; then
        print_step "Installing custom themes..."
        cp -r "$SCRIPT_DIR/themes/"* "$THEMES_DIR/"
        print_success "Custom themes installed"
    fi
    
    # Setup GTK themes
    print_step "Configuring GTK themes..."
    
    # Create GTK-3.0 config
    mkdir -p "$CONFIG_DIR/gtk-3.0"
    cat > "$CONFIG_DIR/gtk-3.0/settings.ini" << 'EOFgtk3setting'
[Settings]
gtk-theme-name=Catppuccin-Mocha-Standard-Blue-Dark
gtk-icon-theme-name=Papirus-Dark
gtk-font-name=Inter 11
gtk-cursor-theme-name=Catppuccin-Mocha-Dark-Cursors
gtk-cursor-theme-size=24
gtk-toolbar-style=GTK_TOOLBAR_BOTH
gtk-toolbar-icon-size=GTK_ICON_SIZE_LARGE_TOOLBAR
gtk-button-images=1
gtk-menu-images=1
gtk-enable-event-sounds=1
gtk-enable-input-feedback-sounds=1
gtk-xft-antialias=1
gtk-xft-hinting=1
gtk-xft-hintstyle=hintfull
gtk-xft-rgba=rgb
EOFgtk3setting
    
    # Create GTK-4.0 config
    mkdir -p "$CONFIG_DIR/gtk-4.0"
    cat > "$CONFIG_DIR/gtk-4.0/settings.ini" << 'EOFgtk4setting'
[Settings]
gtk-theme-name=Catppuccin-Mocha-Standard-Blue-Dark
gtk-icon-theme-name=Papirus-Dark
gtk-font-name=Inter 11
gtk-cursor-theme-name=Catppuccin-Mocha-Dark-Cursors
gtk-cursor-theme-size=24
gtk-application-prefer-dark-theme=1
EOFgtk4setting
    
    print_success "GTK themes configured"
}

# Function to create symlinks
create_symlinks() {
    print_header "Creating Symlinks"
    
    # Create symlinks for scripts in PATH
    local scripts=(
        "notification-manager.sh:mako-manager"
        "system-info.sh:system-info"
        "screenshot.sh:screenshot"
        "power-menu.sh:power-menu"
    )
    
    for script_link in "${scripts[@]}"; do
        local script_name="${script_link%%:*}"
        local link_name="${script_link##*:}"
        local script_path="$CONFIG_DIR/scripts/$script_name"
        local link_path="$LOCAL_BIN/$link_name"
        
        if [[ -f "$script_path" ]]; then
            print_step "Creating symlink: $link_name"
            ln -sf "$script_path" "$link_path"
            print_success "Symlink created: $link_name -> $script_name"
        fi
    done
    
    # Create symlink for Waybar system info module
    if [[ -f "$CONFIG_DIR/waybar/modules/system-info.sh" ]]; then
        ln -sf "$CONFIG_DIR/waybar/modules/system-info.sh" "$LOCAL_BIN/waybar-system-info"
        print_success "Waybar system info symlink created"
    fi
}

# Function to create desktop entries
create_desktop_entries() {
    print_header "Creating Desktop Entries"
    
    # Notification Manager desktop entry
    cat > "$LOCAL_SHARE/applications/notification-manager.desktop" << 'EOFnotificationmanager'
[Desktop Entry]
Name=Notification Manager
Comment=Manage Mako notifications and settings
Exec=alacritty -e mako-manager
Icon=notification-symbolic
Terminal=false
Type=Application
Categories=System;Settings;
Keywords=notifications;mako;settings;manager;
StartupNotify=true
EOFnotificationmanager
    
    # System Information desktop entry
    cat > "$LOCAL_SHARE/applications/system-info.desktop" << 'EOFsystem'
[Desktop Entry]
Name=System Information
Comment=View detailed system information and statistics
Exec=system-info menu
Icon=computer-symbolic
Terminal=false
Type=Application
Categories=System;Monitor;
Keywords=system;info;monitor;stats;hardware;
StartupNotify=true
EOFsystem
    
    # Power Menu desktop entry
    cat > "$LOCAL_SHARE/applications/power-menu.desktop" << 'EOFpower'
[Desktop Entry]
Name=Power Menu
Comment=System power management options
Exec=power-menu
Icon=system-shutdown-symbolic
Terminal=false
Type=Application
Categories=System;
Keywords=power;shutdown;reboot;logout;suspend;
StartupNotify=true
EOFpower
    
    # Screenshot Tool desktop entry
    cat > "$LOCAL_SHARE/applications/screenshot-tool.desktop" << 'EOFscrt'
[Desktop Entry]
Name=Screenshot Tool
Comment=Take screenshots with various options
Exec=screenshot
Icon=camera-photo-symbolic
Terminal=false
Type=Application
Categories=Graphics;Photography;
Keywords=screenshot;capture;image;photo;
StartupNotify=true
EOFscrt
    
    print_success "Desktop entries created"
}

# Function to setup systemd services
setup_systemd_services() {
    print_header "Setting Up System Services"
    
    # Mako notification service
    if command_exists "mako"; then
        print_step "Setting up Mako notification service..."
        
        cat > "$CONFIG_DIR/systemd/user/mako.service" << 'EOFmakoservice'
[Unit]
Description=Mako notification daemon
Documentation=man:mako(1)
PartOf=graphical-session.target
After=graphical-session.target

[Service]
Type=dbus
BusName=org.freedesktop.Notifications
ExecStart=/usr/bin/mako
ExecReload=/bin/kill -SIGUSR1 $MAINPID
Restart=on-failure
RestartSec=1
TimeoutStopSec=10

[Install]
WantedBy=default.target
EOFmakoservice
        
        systemctl --user daemon-reload
        systemctl --user enable mako.service
        print_success "Mako service configured and enabled"
    fi
    
    # System monitor service for Waybar
    print_step "Setting up system monitoring service..."
    
    cat > "$CONFIG_DIR/systemd/user/waybar-system-monitor.service" << 'EOFwaybarsystem'
[Unit]
Description=System Monitor for Waybar
Documentation=Waybar system information module
After=graphical-session.target

[Service]
Type=simple
ExecStart=/bin/bash -c 'while true; do ~/.config/waybar/modules/system-info.sh json > /tmp/waybar-system-info.json 2>/dev/null || echo "{}"; sleep 5; done'
Restart=on-failure
RestartSec=5
TimeoutStopSec=5

[Install]
WantedBy=default.target
EOFwaybarsystem
    
    cat > "$CONFIG_DIR/systemd/user/waybar-system-monitor.timer" << 'EOFwaybartimer'
[Unit]
Description=Run Waybar system monitor every 5 seconds
Requires=waybar-system-monitor.service

[Timer]
OnBootSec=10sec
OnUnitActiveSec=5sec
AccuracySec=1sec

[Install]
WantedBy=timers.target
EOFwaybartimer
    
    systemctl --user daemon-reload
    systemctl --user enable waybar-system-monitor.timer
    print_success "System monitoring service configured"
    
    # Auto-start Hyprland components service
    print_step "Setting up Hyprland autostart service..."
    
    cat > "$CONFIG_DIR/systemd/user/hyprland-autostart.service" << 'EOFhyprstart'
[Unit]
Description=Hyprland autostart applications
After=hyprland-session.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c 'sleep 2 && ~/.config/scripts/autostart.sh'

[Install]
WantedBy=hyprland-session.target
EOFhyprstart
    
    systemctl --user daemon-reload
    systemctl --user enable hyprland-autostart.service
    print_success "Hyprland autostart service configured"
}

# Function to setup environment variables
setup_environment() {
    print_header "Setting Up Environment Variables"
    
    # Create environment file for Hyprland
    cat > "$CONFIG_DIR/hypr/env.conf" << 'EOFenv'
# Environment variables for Hyprland

# XDG
env = XDG_CURRENT_DESKTOP,Hyprland
env = XDG_SESSION_TYPE,wayland
env = XDG_SESSION_DESKTOP,Hyprland

# Qt
env = QT_QPA_PLATFORM,wayland;xcb
env = QT_QPA_PLATFORMTHEME,qt6ct
env = QT_WAYLAND_DISABLE_WINDOWDECORATION,1
env = QT_AUTO_SCREEN_SCALE_FACTOR,1

# GTK
env = GDK_BACKEND,wayland,x11
env = GTK_THEME,Catppuccin-Mocha-Standard-Blue-Dark

# Mozilla
env = MOZ_ENABLE_WAYLAND,1

# Cursor
env = XCURSOR_THEME,Catppuccin-Mocha-Dark-Cursors
env = XCURSOR_SIZE,24

# Other
env = EDITOR,nano
env = BROWSER,firefox
env = TERMINAL,alacritty
EOFenv
    
    # Add to shell profile if it doesn't exist
    local shell_profile=""
    if [[ -n "$BASH_VERSION" ]]; then
        shell_profile="$HOME/.bashrc"
    elif [[ -n "$ZSH_VERSION" ]]; then
        shell_profile="$HOME/.zshrc"
    fi
    
    if [[ -n "$shell_profile" && -f "$shell_profile" ]]; then
        if ! grep -q "# Hyprland dotfiles PATH" "$shell_profile"; then
            print_step "Adding local bin to PATH in $shell_profile..."
            cat >> "$shell_profile" << 'EOFprofileshell'
# Hyprland dotfiles PATH
if [[ -d "$HOME/.local/bin" ]]; then
    export PATH="$HOME/.local/bin:$PATH"
fi
EOFprofileshell          
            print_success "PATH updated in shell profile"
        fi
    fi
    
    print_success "Environment variables configured"
}

# Function to create autostart script
create_autostart_script() {
    print_header "Creating Autostart Script"
    
    cat > "$CONFIG_DIR/scripts/autostart.sh" << 'EOFautostart'
#!/bin/bash

# Hyprland autostart script
# This script is executed when Hyprland starts

# Wait for Hyprland to be ready
sleep 2

# Start Waybar
if command -v waybar &> /dev/null; then
    killall waybar 2>/dev/null || true
    waybar &
fi

# Start Mako notifications
if command -v mako &> /dev/null; then
    killall mako 2>/dev/null || true
    mako &
fi

# Start network manager applet
if command -v nm-applet &> /dev/null; then
    nm-applet --indicator &
fi

# Start audio control
if command -v pavucontrol &> /dev/null; then
    # Don't start pavucontrol automatically, just ensure it's available
    true
fi

# Start clipboard manager
if command -v wl-paste &> /dev/null && command -v wl-copy &> /dev/null; then
    wl-paste --watch wl-copy &
fi

# Set wallpaper if swaybg is available
if command -v swaybg &> /dev/null; then
    if [[ -f "$HOME/.config/hypr/wallpaper.jpg" ]]; then
        swaybg -i "$HOME/.config/hypr/wallpaper.jpg" &
    fi
fi

# Start idle management
if command -v swayidle &> /dev/null; then
    swayidle -w \
        timeout 300 'hyprctl dispatch dpms off' \
        resume 'hyprctl dispatch dpms on' \
        timeout 600 'systemctl suspend' &
fi

echo "Autostart completed"
EOFautostart
    
    chmod +x "$CONFIG_DIR/scripts/autostart.sh"
    print_success "Autostart script created"
}

# Function to validate installation
validate_installation() {
    print_header "Validating Installation"
    
    local validation_errors=()
    
    # Check if configuration files exist
    local required_configs=(
        "$CONFIG_DIR/hypr/hyprland.conf"
        "$CONFIG_DIR/waybar/config"
        "$CONFIG_DIR/waybar/style.css"
        "$CONFIG_DIR/scripts/autostart.sh"
    )
    
    for config in "${required_configs[@]}"; do
        if [[ -f "$config" ]]; then
            print_success "Found: $(basename "$config")"
        else
            validation_errors+=("Missing: $config")
            print_error "Missing: $config"
        fi
    done
    
    # Check if scripts are executable
    local scripts=(
        "$CONFIG_DIR/scripts/autostart.sh"
        "$CONFIG_DIR/scripts/notification-manager.sh"
        "$CONFIG_DIR/waybar/modules/system-info.sh"
    )
    
    for script in "${scripts[@]}"; do
        if [[ -f "$script" && -x "$script" ]]; then
            print_success "Executable: $(basename "$script")"
        elif [[ -f "$script" ]]; then
            validation_errors+=("Not executable: $script")
            print_error "Not executable: $script"
        fi
    done
    
    # Check symlinks
    local symlinks=(
        "$LOCAL_BIN/mako-manager"
        "$LOCAL_BIN/system-info"
    )
    
    for symlink in "${symlinks[@]}"; do
        if [[ -L "$symlink" ]]; then
            print_success "Symlink: $(basename "$symlink")"
        else
            validation_errors+=("Missing symlink: $symlink")
            print_error "Missing symlink: $symlink"
        fi
    done
    
    # Check systemd services
    if systemctl --user list-unit-files | grep -q "mako.service"; then
        print_success "Mako service installed"
    else
        validation_errors+=("Mako service not found")
        print_error "Mako service not found"
    fi
    
    if [[ ${#validation_errors[@]} -eq 0 ]]; then
        print_success "All validation checks passed!"
        return 0
    else
        print_error "Validation failed with ${#validation_errors[@]} errors"
        return 1
    fi
}

# Function to show post-installation information
show_post_install_info() {
    print_header "Installation Complete!"
    
    print_color $GREEN "✅ Hyprland dotfiles installation completed successfully!"
    echo
    
    print_color $CYAN "📋 Next Steps:"
    echo "1. Log out and log back in (or reboot for best results)"
    echo "2. Select Hyprland as your session at login"
    echo "3. The desktop should start automatically with Waybar and notifications"
    echo
    
    print_color $YELLOW "🎮 Key Bindings:"
    echo "• Super + Return        → Open terminal (Alacritty)"
    echo "• Super + D             → Application launcher (Rofi)"
    echo "• Super + Q             → Close window"
    echo "• Super + M             → Exit Hyprland"
    echo "• Super + V             → Toggle floating mode"
    echo "• Super + F             → Toggle fullscreen"
    echo "• Super + 1-9           → Switch workspace"
    echo "• Super + Shift + 1-9   → Move window to workspace"
    echo "• Super + Arrow Keys    → Move focus between windows"
    echo "• Super + Shift + Arrow → Move window"
    echo "• Super + Mouse         → Move/resize windows"
    echo "• Print Screen          → Take screenshot"
    echo "• Super + L             → Lock screen"
    echo
    
    print_color $BLUE "🛠️  Available Commands:"
    echo "• mako-manager          → Manage notifications"
    echo "  - mako-manager status   (check daemon status)"
    echo "  - mako-manager test     (send test notification)"
    echo "  - mako-manager dnd      (toggle Do Not Disturb)"
    echo "  - mako-manager theme    (change notification theme)"
    echo "• system-info           → System information"
    echo "  - system-info detailed  (detailed system info)"
    echo "  - system-info menu      (interactive menu)"
    echo "• screenshot            → Screenshot tool"
    echo "• power-menu            → Power management menu"
    echo
    
    print_color $PURPLE "📁 Configuration Locations:"
    echo "• Hyprland:    ~/.config/hypr/"
    echo "• Waybar:      ~/.config/waybar/"
    echo "• Mako:        ~/.config/mako/"
    echo "• Rofi:        ~/.config/rofi/"
    echo "• Alacritty:   ~/.config/alacritty/"
    echo "• Scripts:     ~/.config/scripts/"
    echo
    
    print_color $WHITE "🎨 Customization Tips:"
    echo "• Edit ~/.config/hypr/hyprland.conf for window manager settings"
    echo "• Edit ~/.config/waybar/config and style.css for status bar"
    echo "• Edit ~/.config/mako/config for notification settings"
    echo "• Use 'mako-manager theme <name>' to change notification themes"
    echo "• Wallpapers go in ~/.config/hypr/ (name it wallpaper.jpg)"
    echo
    
    print_color $CYAN "🔧 Troubleshooting:"
    echo "• Check logs: journalctl --user -xe"
    echo "• Restart Waybar: killall waybar && waybar &"
    echo "• Restart notifications: killall mako && mako &"
    echo "• Reload Hyprland config: hyprctl reload"
    echo "• Test notifications: notify-send 'Test' 'Hello World'"
    echo
    
    # Check if backup was created
    local backup_dir=$(find "$HOME/.config" -maxdepth 1 -name "dotfiles-backup-*" -type d 2>/dev/null | tail -1)
    if [[ -n "$backup_dir" ]]; then
        print_color $YELLOW "💾 Backup Information:"
        echo "• Your previous configurations were backed up to:"
        echo "  $backup_dir"
        echo "• Use '$backup_dir/restore.sh' to restore if needed"
        echo
    fi
    
    # Show optional dependencies reminder
    print_color $BLUE "📦 Optional Enhancements:"
    echo "For the best experience, consider installing:"
    echo "• firefox or chromium (web browser)"
    echo "• thunar or nautilus (file manager)"
    echo "• swaylock (screen locker)"
    echo "• swaybg (wallpaper setter)"
    echo "• swayidle (idle management)"
    echo "• grim + slurp + swappy (screenshot tools)"
    echo "• playerctl (media control)"
    echo "• brightnessctl (brightness control)"
    echo
    
    print_color $GREEN "🎉 Enjoy your new Hyprland setup!"
    print_color $WHITE "⭐ If you like this configuration, please star the repository!"
    echo
}

# Function to handle cleanup on exit
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        print_error "Installation failed with exit code $exit_code"
        print_color $YELLOW "💡 Check the error messages above for troubleshooting"
        print_color $BLUE "🔍 Common solutions:"
        echo "• Make sure all required dependencies are installed"
        echo "• Check file permissions in the dotfiles directory"
        echo "• Ensure you have write access to ~/.config/"
        echo "• Try running the script with bash -x install.sh for debug info"
    fi
}

# Function to check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_error "This script should not be run as root!"
        print_color $YELLOW "Please run as a regular user:"
        print_color $CYAN "  ./install.sh"
        exit 1
    fi
}

# Function to show help
show_help() {
    cat << EOFhelp
Hyprland Dotfiles Installation Script

USAGE:
    ./install.sh [OPTIONS]

OPTIONS:
    -h, --help          Show this help message
    -f, --force         Force installation without prompts
    -b, --backup-only   Only create backup, don't install
    -v, --validate      Validate existing installation
    --skip-deps         Skip dependency checks
    --skip-fonts        Skip font installation
    --skip-themes       Skip theme setup
    --skip-services     Skip systemd service setup

EXAMPLES:
    ./install.sh                    # Normal installation
    ./install.sh --force            # Install without prompts
    ./install.sh --validate         # Check existing installation
    ./install.sh --backup-only      # Only create backup

For more information, visit: https://github.com/yourusername/hyprland-dotfiles
EOFhelp
}

# Parse command line arguments
parse_arguments() {
    FORCE_INSTALL=false
    BACKUP_ONLY=false
    VALIDATE_ONLY=false
    SKIP_DEPS=false
    SKIP_FONTS=false
    SKIP_THEMES=false
    SKIP_SERVICES=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -f|--force)
                FORCE_INSTALL=true
                shift
                ;;
            -b|--backup-only)
                BACKUP_ONLY=true
                shift
                ;;
            -v|--validate)
                VALIDATE_ONLY=true
                shift
                ;;
            --skip-deps)
                SKIP_DEPS=true
                shift
                ;;
            --skip-fonts)
                SKIP_FONTS=true
                shift
                ;;
            --skip-themes)
                SKIP_THEMES=true
                shift
                ;;
            --skip-services)
                SKIP_SERVICES=true
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

# Main installation function
main() {
    # Set up error handling
    trap cleanup EXIT
    
    # Parse arguments
    parse_arguments "$@"
    
    # Show header
    print_header "Hyprland Dotfiles Installation Script"
    print_color $BLUE "🚀 Starting installation process..."
    echo
    
    # Check if running as root
    check_root
    
    # Handle special modes
    if [[ "$VALIDATE_ONLY" == true ]]; then
        validate_installation
        exit $?
    fi
    
    if [[ "$BACKUP_ONLY" == true ]]; then
        create_backup
        exit 0
    fi
    
    # Check system compatibility
    check_system
    
    # Check dependencies
    if [[ "$SKIP_DEPS" != true ]]; then
        check_dependencies
    fi
    
    # Confirm installation unless forced
    if [[ "$FORCE_INSTALL" != true ]]; then
        echo
        print_color $YELLOW "⚠️  This will install Hyprland dotfiles and may overwrite existing configurations."
        read -p "Do you want to continue? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            print_color $BLUE "Installation cancelled by user"
            exit 0
        fi
    fi
    
    # Start installation process
    print_color $GREEN "🎯 Starting installation..."
    echo
    
    # Create backup of existing configurations
    create_backup
    
    # Create necessary directories
    create_directories
    
    # Copy configuration files
    copy_configs
    
    # Set proper file permissions
    set_permissions
    
    # Install fonts
    if [[ "$SKIP_FONTS" != true ]]; then
        install_fonts
    fi
    
    # Setup themes
    if [[ "$SKIP_THEMES" != true ]]; then
        setup_themes
    fi
    
    # Create symlinks
    create_symlinks
    
    # Create desktop entries
    create_desktop_entries
    
    # Setup systemd services
    if [[ "$SKIP_SERVICES" != true ]]; then
        setup_systemd_services
    fi
    
    # Setup environment variables
    setup_environment
    
    # Create autostart script
    create_autostart_script
    
    # Validate installation
    if validate_installation; then
        show_post_install_info
    else
        print_error "Installation completed with some issues"
        print_color $YELLOW "💡 The configuration should still work, but some features may be limited"
        exit 1
    fi
}

# Run main function if script is executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
# End of script