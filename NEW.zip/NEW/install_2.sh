        cp config/waybar/modules/system-info.sh ~/.config/waybar/modules/
        chmod +x ~/.config/waybar/modules/system-info.sh
        print_color $GREEN "✅ Waybar system info module copied"
    fi
    
    # Copy notification management scripts
    if [[ -f "config/scripts/notification-manager.sh" ]]; then
        print_color $BLUE "🔔 Copying notification management scripts..."
        mkdir -p ~/.config/scripts
        cp config/scripts/notification-manager.sh ~/.config/scripts/
        chmod +x ~/.config/scripts/notification-manager.sh
        print_color $GREEN "✅ Notification manager script copied"
    fi
    
    # Setup Mako if configuration exists
    if [[ -f "setup/mako/config" ]]; then
        print_color $BLUE "⚙️  Setting up Mako notification daemon..."
        source setup/mako/config
        main_setup
        print_color $GREEN "✅ Mako setup completed"
    fi
}

# Función para crear enlaces simbólicos adicionales
create_additional_symlinks() {
    print_header "Creating Additional Symlinks"
    
    # Create symlink for notification manager in PATH
    if [[ -f ~/.config/scripts/notification-manager.sh ]]; then
        mkdir -p ~/.local/bin
        ln -sf ~/.config/scripts/notification-manager.sh ~/.local/bin/mako-manager
        print_color $GREEN "✅ Created mako-manager symlink"
    fi
    
    # Create symlink for system info script
    if [[ -f ~/.config/waybar/modules/system-info.sh ]]; then
        ln -sf ~/.config/waybar/modules/system-info.sh ~/.local/bin/system-info
        print_color $GREEN "✅ Created system-info symlink"
    fi
    
    # Create desktop entries
    create_desktop_entries
}

# Función para crear entradas de escritorio
create_desktop_entries() {
    print_color $BLUE "🖥️  Creating desktop entries..."
    
    mkdir -p ~/.local/share/applications
    
    # Notification Manager desktop entry
    cat > ~/.local/share/applications/notification-manager.desktop << 'EOF'
[Desktop Entry]
Name=Notification Manager
Comment=Manage Mako notifications
Exec=alacritty -e mako-manager
Icon=notification-symbolic
Terminal=false
Type=Application
Categories=System;Settings;
Keywords=notifications;mako;settings;
EOF

    # System Info desktop entry
    cat > ~/.local/share/applications/system-info.desktop << 'EOF'
[Desktop Entry]
Name=System Information
Comment=View detailed system information
Exec=system-info menu
Icon=computer-symbolic
Terminal=false
Type=Application
Categories=System;Monitor;
Keywords=system;info;monitor;stats;
EOF

    print_color $GREEN "✅ Desktop entries created"
}

# Función para verificar dependencias adicionales
check_additional_dependencies() {
    print_header "Checking Additional Dependencies"
    
    local missing_deps=()
    
    # Check for Mako
    if ! command -v mako &> /dev/null; then
        missing_deps+=("mako")
    fi
    
    # Check for Alacritty
    if ! command -v alacritty &> /dev/null; then
        missing_deps+=("alacritty")
    fi
    
    # Check for jq (for notification history)
    if ! command -v jq &> /dev/null; then
        missing_deps+=("jq")
    fi
    
    # Check for sensors (for temperature monitoring)
    if ! command -v sensors &> /dev/null; then
        missing_deps+=("lm-sensors")
    fi
    
    # Check for xclip (for clipboard functionality)
    if ! command -v xclip &> /dev/null; then
        missing_deps+=("xclip")
    fi
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        print_color $YELLOW "⚠️  Missing optional dependencies:"
        for dep in "${missing_deps[@]}"; do
            print_color $YELLOW "  - $dep"
        done
        echo
        print_color $BLUE "Install them with your package manager:"
        
        # Detect package manager and show appropriate command
        if command -v pacman &> /dev/null; then
            print_color $CYAN "  sudo pacman -S ${missing_deps[*]}"
        elif command -v apt &> /dev/null; then
            print_color $CYAN "  sudo apt install ${missing_deps[*]}"
        elif command -v dnf &> /dev/null; then
            print_color $CYAN "  sudo dnf install ${missing_deps[*]}"
        elif command -v zypper &> /dev/null; then
            print_color $CYAN "  sudo zypper install ${missing_deps[*]}"
        else
            print_color $CYAN "  Use your package manager to install: ${missing_deps[*]}"
        fi
        echo
    else
        print_color $GREEN "✅ All additional dependencies are installed"
    fi
}

# Función para configurar servicios del sistema
setup_system_services() {
    print_header "Setting Up System Services"
    
    # Setup Mako service
    if command -v mako &> /dev/null; then
        print_color $BLUE "🔔 Setting up Mako notification service..."
        
        mkdir -p ~/.config/systemd/user
        
        cat > ~/.config/systemd/user/mako.service << 'EOF'
[Unit]
Description=Mako notification daemon
PartOf=graphical-session.target
After=graphical-session.target

[Service]
Type=dbus
BusName=org.freedesktop.Notifications
ExecStart=/usr/bin/mako
Restart=on-failure
RestartSec=1
TimeoutStopSec=10

[Install]
WantedBy=default.target
EOF
        
        systemctl --user daemon-reload
        systemctl --user enable mako.service
        print_color $GREEN "✅ Mako service configured and enabled"
    fi
    
    # Setup system monitoring service (optional)
    print_color $BLUE "📊 Setting up system monitoring service..."
    
    cat > ~/.config/systemd/user/system-monitor.service << 'EOF'
[Unit]
Description=System Monitor for Waybar
After=graphical-session.target

[Service]
Type=simple
ExecStart=/bin/bash -c 'while true; do ~/.config/waybar/modules/system-info.sh > /tmp/waybar-system-info.json; sleep 5; done'
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF
    
    cat > ~/.config/systemd/user/system-monitor.timer << 'EOF'
[Unit]
Description=Run system monitor every 5 seconds
Requires=system-monitor.service

[Timer]
OnBootSec=10sec
OnUnitActiveSec=5sec

[Install]
WantedBy=timers.target
EOF
    
    systemctl --user daemon-reload
    systemctl --user enable system-monitor.timer
    print_color $GREEN "✅ System monitoring service configured"
}

# Función para crear configuración de respaldo
create_backup_config() {
    print_header "Creating Backup Configuration"
    
    local backup_dir="$HOME/.config/dotfiles-backup-$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    
    # Backup existing configurations
    local configs_to_backup=(
        "hypr"
        "waybar"
        "mako"
        "alacritty"
        "rofi"
        "scripts"
    )
    
    for config in "${configs_to_backup[@]}"; do
        if [[ -d "$HOME/.config/$config" ]]; then
            print_color $BLUE "💾 Backing up $config configuration..."
            cp -r "$HOME/.config/$config" "$backup_dir/"
            print_color $GREEN "✅ $config backed up"
        fi
    done
    
    # Create restore script
    cat > "$backup_dir/restore.sh" << EOF
#!/bin/bash

# Restore script for dotfiles backup
# Created: $(date)

echo "🔄 Restoring dotfiles backup..."

BACKUP_DIR="\$(dirname "\$0")"
CONFIG_DIR="\$HOME/.config"

for item in "\$BACKUP_DIR"/*; do
    if [[ -d "\$item" && "\$(basename "\$item")" != "." && "\$(basename "\$item")" != ".." ]]; then
        config_name="\$(basename "\$item")"
        if [[ "\$config_name" != "restore.sh" ]]; then
            echo "Restoring \$config_name..."
            rm -rf "\$CONFIG_DIR/\$config_name"
            cp -r "\$item" "\$CONFIG_DIR/"
        fi
    fi
done

echo "✅ Backup restored successfully"
echo "💡 You may need to restart your session for changes to take effect"
EOF
    
    chmod +x "$backup_dir/restore.sh"
    
    print_color $GREEN "✅ Backup created at: $backup_dir"
    print_color $BLUE "💡 Use '$backup_dir/restore.sh' to restore if needed"
}

# Función principal actualizada
main() {
    print_header "Hyprland Dotfiles Installation Script"
    
    # Check if running on supported system
    check_system
    
    # Check dependencies
    check_dependencies
    check_additional_dependencies
    
    # Create backup
    create_backup_config
    
    # Create necessary directories
    create_directories
    
    # Copy configuration files
    copy_configs
    copy_additional_configs
    
    # Set permissions
    set_permissions
    
    # Create symlinks
    create_symlinks
    create_additional_symlinks
    
    # Setup system services
    setup_system_services
    
    # Install fonts
    install_fonts
    
    # Setup themes
    setup_themes
    
    print_header "Installation Complete!"
    
    print_color $GREEN "✅ Dotfiles installation completed successfully!"
    echo
    print_color $CYAN "📋 Next Steps:"
    echo "1. Log out and log back in (or reboot)"
    echo "2. Select Hyprland as your session"
    echo "3. Use Super+Return to open terminal"
    echo "4. Use Super+D to open application launcher"
    echo "5. Use Super+Q to quit applications"
    echo "6. Use mako-manager to manage notifications"
    echo "7. Use system-info menu to view system information"
    echo
    print_color $YELLOW "🔧 Configuration Files:"
    echo "- Hyprland: ~/.config/hypr/"
    echo "- Waybar: ~/.config/waybar/"
    echo "- Mako: ~/.config/mako/"
    echo "- Alacritty: ~/.config/alacritty/"
    echo "- Rofi: ~/.config/rofi/"
    echo "- Scripts: ~/.config/scripts/"
    echo
    print_color $BLUE "💡 Useful Commands:"
    echo "- mako-manager status    # Check notification daemon"
    echo "- mako-manager test      # Send test notifications"
    echo "- mako-manager dnd       # Toggle Do Not Disturb"
    echo "- system-info menu       # System information menu"
    echo "- hyprctl reload         # Reload Hyprland config"
    echo
    print_color $PURPLE "🎨 Customization:"
    echo "- Edit ~/.config/hypr/hyprland.conf for window manager settings"
    echo "- Edit ~/.config/waybar/config for status bar"
    echo "- Edit ~/.config/mako/config for notifications"
    echo "- Use mako-manager theme <name> to change notification themes"
    echo
    
    # Check if reboot is recommended
    if systemctl --user is-enabled mako.service &>/dev/null; then
        print_color $YELLOW "⚠️  Reboot recommended to ensure all services start properly"
    fi
    
    print_color $GREEN "🎉 Enjoy your new Hyprland setup!"
}

# Run main function if script is executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi