#!/usr/bin/env bash

set -e

# NARF MODE: Universal full installer for hyprland-dotfiles

# Colors
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[34m"
RESET="\e[0m"

# Detect GPU Type
detect_gpu() {
    if lspci | grep -E "NVIDIA|GeForce"; then
        echo "nvidia"
    elif lspci | grep -E "Radeon|AMD"; then
        echo "amd"
    elif lspci | grep -E "Intel"; then
        echo "intel"
    else
        echo "unknown"
    fi
}

GPU=$(detect_gpu)
echo -e "${BLUE}Detected GPU: $GPU${RESET}"

# Base Packages
BASE_PKGS=(
  hyprland hyprpaper hyprlock hypridle waybar rofi dunst
  alacritty thunar thunar-archive-plugin pavucontrol blueman
  network-manager-applet brightnessctl playerctl wf-recorder grim slurp swappy
  wl-clipboard cliphist starship fish zsh neofetch btop htop
  polkit-gnome qt5-wayland qt6-wayland qt5ct qt6ct
)

echo -e "${BLUE}Installing base packages...${RESET}"
sudo pacman -Sy --needed --noconfirm "${BASE_PKGS[@]}"

# Install NVIDIA packages if required
if [[ "$GPU" == "nvidia" ]]; then
    echo -e "${BLUE}Installing NVIDIA packages...${RESET}"
    sudo pacman -Sy --needed --noconfirm nvidia nvidia-utils nvidia-settings egl-wayland
    bash ./scripts/install/nvidia-setup.sh
fi

# Install Hybrid GPU packages if required
if [[ "$GPU" == "hybrid" ]]; then
    echo -e "${BLUE}Installing Hybrid GPU packages...${RESET}"
    bash ./scripts/install/hybrid-gpu-setup.sh
fi

# Apply Configs
bash ./scripts/install/configs-setup.sh

# Install Waydroid (optional)
read -p "Do you want to install Waydroid? (y/n): " waydroid_choice
if [[ "$waydroid_choice" == "y" ]]; then
    bash ./scripts/install/waydroid-setup.sh
fi

# Enable services
echo -e "${BLUE}Enabling services...${RESET}"
sudo systemctl enable bluetooth.service
sudo systemctl enable NetworkManager.service

# VPN module for Waybar (generic)
VPN_MODULE="$HOME/.config/waybar/scripts/vpn_status.sh"
mkdir -p "$HOME/.config/waybar/scripts"

cat << 'EOF2' > "$VPN_MODULE"
#!/bin/bash

if ip a | grep -qE 'tun|wg|vpn'; then
    echo '{"text":"🔒 VPN","class":"connected"}'
else
    echo '{"text":"🔓 No VPN","class":"disconnected"}'
fi
EOF2

chmod +x "$VPN_MODULE"

echo -e "${GREEN}Installation completed successfully!${RESET}"
